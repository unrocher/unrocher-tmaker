
import React, { useEffect, useMemo, useRef, useState } from "react";
import { Dices, Star, Download, Repeat2, House, Minus, Plus, FileText, Printer, Save, Trash2, ClipboardPlus, Lock } from "lucide-react";
import { shirts } from "./shirts-data";
import { designs, getInitialPlacement, getSavedBasePlacements } from "./designs-data";

const inkPresets = [
  { id: "light-green", name: "浅緑 / ライトグリーン", color: "#c7d2bc" },
  { id: "vermilion", name: "朱 / バーミリオン", color: "#bd1737" },
  { id: "light-gray", name: "深川鼠色 / ライトグレー", color: "#b7b7b9" },
  { id: "brown", name: "茶 / パイロンブラウン", color: "#835632" },
  { id: "anrocher-blue", name: "蒼緑 / アンロシェブルー", color: "#41b4bb" },
  { id: "black", name: "黒 / ブラック", color: "#201010" },
  { id: "white", name: "白 / ホワイト", color: "#ffffff" },
  { id: "masking-green", name: "若草 / マスキンググリーン", color: "#85c17a" },
  { id: "anrocher-pink", name: "薄橙 / アンロシェピンク", color: "#eac8bd" },
];

const sizeSpec = {
  "120": { code: "21", bodyLengthCm: 48 },
  "130": { code: "22", bodyLengthCm: 52 },
  "140": { code: "23", bodyLengthCm: 56 },
  "150": { code: "24", bodyLengthCm: 60 },
  XS: { code: "98", bodyLengthCm: 63 },
  S: { code: "01", bodyLengthCm: 66 },
  M: { code: "02", bodyLengthCm: 70 },
  L: { code: "03", bodyLengthCm: 74 },
  XL: { code: "07", bodyLengthCm: 78 },
  XXL: { code: "45", bodyLengthCm: 82 },
};

const ALL_SIZES = ["120", "130", "140", "150", "XS", "S", "M", "L", "XL", "XXL"];
const EDITABLE_SIZES = ["120", "M", "XXL"];

const BASE_PRINT_SIZE = "M";
const PLACEMENT_STORAGE_KEY = "anrocher-design-placements-v7";
const FAVORITES_STORAGE_KEY = "anrocher-favorites-v1";
const ORDER_STORAGE_KEY = "anrocher-order-drafts-v1";
const DESIGN_ADJUST_AUTH_STORAGE_KEY = "anrocher-design-adjust-auth-v1";
const MAX_FAVORITES = 30;
const APP_VERSION = "V04.0.4.7-preview-dpr-native-pinch";
const DESIGNS_DATA_VERSION = "from-generate-designs-current";

/**
 * 注意:
 * これはフロント側の簡易ロックです。
 * 本気のセキュリティにはなりません。
 * 外部公開ページでの誤操作防止用として使ってください。
 */
const DESIGN_ADJUST_PASSWORD = "CHANGE-ME-UNROCHER";

const MIN_ZOOM = 1;
const MAX_ZOOM = 3;
const HANDLE_SIZE = 14;
const MIN_WIDTH_CM = 5;
const MAX_WIDTH_CM = 45;
const HIGH_RES_EXPORT_SIZE = 3000;

function forceSingleColorSvg(svgText, color) {
  if (!svgText) return "";

  let out = svgText;

  const normalize = (value) => String(value).trim().toLowerCase().replace(/\s+/g, "");

  const isWhite = (value) => {
    const v = normalize(value);
    return (
      v === "#fff" ||
      v === "#ffffff" ||
      v === "white" ||
      v === "rgb(255,255,255)" ||
      v === "rgb(100%,100%,100%)"
    );
  };

  const isNone = (value) => normalize(value) === "none";

  out = out.replace(/fill\s*:\s*([^;"']+)/gi, (match, value) => {
    if (isNone(value)) return match;
    if (isWhite(value)) return "fill:none";
    return `fill:${color}`;
  });

  out = out.replace(/stroke\s*:\s*([^;"']+)/gi, (match, value) => {
    if (isNone(value)) return match;
    if (isWhite(value)) return "stroke:none";
    return `stroke:${color}`;
  });

  out = out.replace(/fill="([^"]*)"/gi, (match, value) => {
    if (isNone(value)) return match;
    if (isWhite(value)) return 'fill="none"';
    return `fill="${color}"`;
  });

  out = out.replace(/stroke="([^"]*)"/gi, (match, value) => {
    if (isNone(value)) return match;
    if (isWhite(value)) return 'stroke="none"';
    return `stroke="${color}"`;
  });

  out = out.replace(
    /<(path|polygon|rect|circle|ellipse|text|polyline)([^>]*?)\/>/gi,
    (m, tag, attrs) => {
      const hasFill = /\sfill=/.test(attrs) || /fill\s*:/.test(attrs);
      const hasStroke = /\sstroke=/.test(attrs) || /stroke\s*:/.test(attrs);
      if (hasFill || hasStroke) return m;
      return `<${tag}${attrs} fill="${color}" />`;
    }
  );

  out = out.replace(
    /<(path|polygon|rect|circle|ellipse|text|polyline)([^>]*?)>/gi,
    (m, tag, attrs) => {
      const hasFill = /\sfill=/.test(attrs) || /fill\s*:/.test(attrs);
      const hasStroke = /\sstroke=/.test(attrs) || /stroke\s*:/.test(attrs);
      if (hasFill || hasStroke) return m;
      return `<${tag}${attrs} fill="${color}">`;
    }
  );

  return out;
}

async function fetchText(url) {
  const res = await fetch(url);
  if (!res.ok) throw new Error(`読み込み失敗: ${url}`);
  return res.text();
}

async function downloadCanvas(canvas, fileName) {
  const blob = await new Promise((resolve) => {
    canvas.toBlob((result) => resolve(result), "image/png");
  });

  if (!blob) {
    throw new Error("PNG blob creation failed");
  }

  const file = new File([blob], fileName, { type: "image/png" });
  const nav = typeof navigator !== "undefined" ? navigator : null;

  if (nav?.canShare && nav?.share) {
    try {
      if (nav.canShare({ files: [file] })) {
        await nav.share({
          files: [file],
          title: fileName,
        });
        return "shared";
      }
    } catch (error) {
      if (error?.name === "AbortError") {
        return "cancelled";
      }
    }
  }

  const blobUrl = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = blobUrl;
  link.download = fileName;
  link.rel = "noopener noreferrer";
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);

  setTimeout(() => {
    URL.revokeObjectURL(blobUrl);
  }, 1500);

  return "downloaded";
}

function panelStyle(compact = false) {
  return {
    background: "#ffffff",
    borderRadius: compact ? 16 : 20,
    padding: compact ? 12 : 16,
    boxShadow: "0 8px 24px rgba(0,0,0,0.08)",
    minWidth: 0,
  };
}

function labelStyle() {
  return {
    display: "block",
    fontSize: 14,
    fontWeight: 700,
    marginBottom: 8,
  };
}

function buttonStyle(active = false, compact = false) {
  return {
    padding: compact ? "9px 11px" : "10px 14px",
    borderRadius: 12,
    border: active ? "2px solid #111" : "1px solid #d6d3d1",
    background: active ? "#f5f5f4" : "#fff",
    cursor: "pointer",
    fontWeight: 700,
    fontSize: compact ? 13 : 14,
  };
}

function inputStyle(compact = false) {
  return {
    width: "100%",
    padding: compact ? "9px 11px" : "10px 12px",
    borderRadius: 12,
    border: "1px solid #d6d3d1",
    boxSizing: "border-box",
    minWidth: 0,
  };
}

function IconButton({ title, onClick, compact = false, children, ariaLabel, active = false }) {
  return (
    <button
      type="button"
      title={title}
      aria-label={ariaLabel || title}
      style={{
        ...buttonStyle(active, compact),
        width: compact ? 40 : 44,
        height: compact ? 40 : 44,
        padding: 0,
        display: "inline-flex",
        alignItems: "center",
        justifyContent: "center",
        flexShrink: 0,
      }}
      onClick={onClick}
    >
      {children}
    </button>
  );
}

function safeClone(obj) {
  return JSON.parse(JSON.stringify(obj));
}

function roundPlacement(face) {
  return {
    x: Number((face?.x ?? 50).toFixed(2)),
    y: Number((face?.y ?? 30).toFixed(2)),
    widthCm: Number((face?.widthCm ?? 28).toFixed(2)),
    flipX: Boolean(face?.flipX),
  };
}

function formatPlacementInline(face) {
  const p = roundPlacement(face);
  return `{ x: ${p.x}, y: ${p.y}, widthCm: ${p.widthCm}, flipX: ${p.flipX} }`;
}

function loadSavedPlacements() {
  if (typeof window === "undefined") return {};
  try {
    const raw = window.localStorage.getItem(PLACEMENT_STORAGE_KEY);
    if (!raw) return {};
    const parsed = JSON.parse(raw);
    return parsed && typeof parsed === "object" ? parsed : {};
  } catch {
    return {};
  }
}

function savePlacementsToStorage(map) {
  if (typeof window === "undefined") return;
  try {
    window.localStorage.setItem(PLACEMENT_STORAGE_KEY, JSON.stringify(map));
  } catch {
    // ignore
  }
}

function clearAllPlacementsStorage() {
  if (typeof window === "undefined") return;
  try {
    window.localStorage.removeItem(PLACEMENT_STORAGE_KEY);
  } catch {
    // ignore
  }
}

function loadFavorites() {
  if (typeof window === "undefined") return [];
  try {
    const raw = window.localStorage.getItem(FAVORITES_STORAGE_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}

function saveFavoritesToStorage(items) {
  if (typeof window === "undefined") return;
  try {
    window.localStorage.setItem(FAVORITES_STORAGE_KEY, JSON.stringify(items.slice(0, MAX_FAVORITES)));
  } catch {
    // ignore
  }
}

function loadOrderDrafts() {
  if (typeof window === "undefined") return [];
  try {
    const raw = window.localStorage.getItem(ORDER_STORAGE_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}

function saveOrderDraftsToStorage(items) {
  if (typeof window === "undefined") return;
  try {
    window.localStorage.setItem(ORDER_STORAGE_KEY, JSON.stringify(items));
  } catch {
    // ignore
  }
}

function loadDesignAdjustAuth() {
  if (typeof window === "undefined") return false;
  try {
    return window.sessionStorage.getItem(DESIGN_ADJUST_AUTH_STORAGE_KEY) === "ok";
  } catch {
    return false;
  }
}

function saveDesignAdjustAuth(value) {
  if (typeof window === "undefined") return;
  try {
    if (value) {
      window.sessionStorage.setItem(DESIGN_ADJUST_AUTH_STORAGE_KEY, "ok");
    } else {
      window.sessionStorage.removeItem(DESIGN_ADJUST_AUTH_STORAGE_KEY);
    }
  } catch {
    // ignore
  }
}

function createEmptyOrderLine(seed = {}) {
  return {
    id: `line-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
    designId: seed.designId || "",
    shirtCode: seed.shirtCode || "",
    inkColor: seed.inkColor || "",
    inkColorHex: seed.inkColorHex || "",
    fit: seed.fit || "M",
    qty: seed.qty ?? 1,
    unitPrice: seed.unitPrice ?? 3800,
    memo: seed.memo || "",
  };
}

function createEmptyOrderDraft() {
  const today = new Date().toISOString().slice(0, 10);
  return {
    id: `order-${Date.now()}`,
    orderDate: today,
    customerName: "",
    phone: "",
    address: "",
    deliveryDate: "",
    paymentStatus: "未",
    note: "",
    lines: [createEmptyOrderLine()],
  };
}

function formatYen(value) {
  const num = Number(value) || 0;
  return `¥${num.toLocaleString("ja-JP")}`;
}

function OrderPanel({
  compact,
  isMobile,
  isTablet,
  draft,
  setDraft,
  savedOrders,
  setSavedOrders,
  onBackToMaker,
  onAddCurrentSelection,
  onOpenBaseOrderPage,
  hasBaseOrderUrl,
  currentSelectionLabel,
  designs,
  shirts,
}) {
  const updateField = (key, value) => {
    setDraft((prev) => ({ ...prev, [key]: value }));
  };

  const updateLine = (lineId, key, value) => {
    setDraft((prev) => ({
      ...prev,
      lines: prev.lines.map((line) => (line.id === lineId ? { ...line, [key]: value } : line)),
    }));
  };

  const addLine = () => {
    setDraft((prev) => ({ ...prev, lines: [...prev.lines, createEmptyOrderLine()] }));
  };

  const removeLine = (lineId) => {
    setDraft((prev) => ({
      ...prev,
      lines: prev.lines.length <= 1 ? prev.lines : prev.lines.filter((line) => line.id !== lineId),
    }));
  };

  const subtotal = draft.lines.reduce((sum, line) => sum + (Number(line.qty) || 0) * (Number(line.unitPrice) || 0), 0);
  const total = subtotal;

  const saveDraft = () => {
    const next = [
      { ...draft, savedAt: new Date().toISOString() },
      ...savedOrders.filter((item) => item.id !== draft.id),
    ].slice(0, 50);
    setSavedOrders(next);
    saveOrderDraftsToStorage(next);
  };

  const loadDraft = (item) => {
    setDraft({ ...item });
  };

  const deleteDraft = (id) => {
    const next = savedOrders.filter((item) => item.id !== id);
    setSavedOrders(next);
    saveOrderDraftsToStorage(next);
  };

  const startNew = () => {
    setDraft(createEmptyOrderDraft());
  };

  return (
    <div style={{ display: "grid", gap: isTablet ? 16 : 24, minWidth: 0 }}>
      <div style={panelStyle(compact)}>
        <div style={{ display: "flex", justifyContent: "space-between", gap: 10, flexWrap: "wrap", alignItems: "center", marginBottom: 16 }}>
          <div style={{ minWidth: 0 }}>
            <img
              src="/title.svg"
              alt="アンロシェカスタムTメーカー"
              style={{
                display: "block",
                width: isMobile ? "100%" : 320,
                maxWidth: "100%",
                height: "auto",
              }}
            />
            <div style={{ fontSize: 12, color: "#78716c", marginTop: 6 }}>発注書</div>
          </div>
          <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
            <button
              type="button"
              style={{
                ...buttonStyle(false, compact),
                display: "inline-flex",
                alignItems: "center",
                gap: 6,
              }}
              onClick={onBackToMaker}
            >
              <House size={16} />
              <span>戻る</span>
            </button>
            <IconButton title="現在の内容を明細に追加" ariaLabel="現在の内容を明細に追加" compact={compact} onClick={onAddCurrentSelection}>
              <ClipboardPlus size={18} />
            </IconButton>
            <IconButton title="保存" ariaLabel="発注書を保存" compact={compact} onClick={saveDraft}>
              <Save size={18} />
            </IconButton>
            <button
              type="button"
              title={hasBaseOrderUrl ? "BASEで注文する" : "このデザインはまだBASE未設定"}
              aria-label={hasBaseOrderUrl ? "BASEで注文する" : "このデザインはまだBASE未設定"}
              style={{
                ...buttonStyle(false, compact),
                display: "inline-flex",
                alignItems: "center",
                gap: 6,
                opacity: hasBaseOrderUrl ? 1 : 0.5,
                cursor: hasBaseOrderUrl ? "pointer" : "not-allowed",
              }}
              onClick={onOpenBaseOrderPage}
              disabled={!hasBaseOrderUrl}
            >
              <span>BASEで注文する</span>
            </button>
            <IconButton title="印刷" ariaLabel="発注書を印刷" compact={compact} onClick={() => window.print()}>
              <Printer size={18} />
            </IconButton>
          </div>
        </div>

        <div style={{ ...inputStyle(compact), marginBottom: 14, background: "#fafaf9", color: "#57534e", fontWeight: 700 }}>
          現在の選択内容: {currentSelectionLabel}
        </div>

        <div style={{ display: "grid", gridTemplateColumns: isMobile ? "1fr" : "repeat(2, minmax(0, 1fr))", gap: 10, marginBottom: 16 }}>
          <div>
            <label style={labelStyle()}>発注日</label>
            <input type="date" value={draft.orderDate} onChange={(e) => updateField("orderDate", e.target.value)} style={inputStyle(compact)} />
          </div>
          <div>
            <label style={labelStyle()}>お客様名</label>
            <input value={draft.customerName} onChange={(e) => updateField("customerName", e.target.value)} style={inputStyle(compact)} />
          </div>
          <div>
            <label style={labelStyle()}>電話</label>
            <input value={draft.phone || ""} onChange={(e) => updateField("phone", e.target.value)} style={inputStyle(compact)} />
          </div>
          <div style={{ gridColumn: isMobile ? "auto" : "1 / -1" }}>
            <label style={labelStyle()}>住所</label>
            <input value={draft.address || ""} onChange={(e) => updateField("address", e.target.value)} style={inputStyle(compact)} />
          </div>
          <div>
            <label style={labelStyle()}>お渡し予定日</label>
            <input type="date" value={draft.deliveryDate} onChange={(e) => updateField("deliveryDate", e.target.value)} style={inputStyle(compact)} />
          </div>
          <div>
            <label style={labelStyle()}>支払い状況</label>
            <select value={draft.paymentStatus} onChange={(e) => updateField("paymentStatus", e.target.value)} style={inputStyle(compact)}>
              <option>未</option>
              <option>済</option>
            </select>
          </div>
        </div>

        <div style={{ fontWeight: 800, fontSize: 18, marginBottom: 10 }}>注文明細</div>
        <div style={{ display: "grid", gap: 10, marginBottom: 14 }}>
          {draft.lines.map((line, index) => {
            const amount = (Number(line.qty) || 0) * (Number(line.unitPrice) || 0);
            const inkPreset = getInkPresetByValue(line.inkColor, line.inkColorHex);
            const lineTint = inkPreset ? hexToRgba(inkPreset.color, 0.22) : "#fff";
            const inkFieldTint = inkPreset ? hexToRgba(inkPreset.color, 0.34) : "#fff";
            return (
              <div key={line.id} style={{ border: "1px solid #e7e5e4", borderRadius: 16, padding: compact ? 10 : 12, background: lineTint }}>
                <div style={{ display: "flex", justifyContent: "space-between", gap: 8, alignItems: "center", marginBottom: 10 }}>
                  <div style={{ fontWeight: 800 }}>明細 {index + 1}</div>
                  <IconButton title="この明細を削除" ariaLabel="この明細を削除" compact={compact} onClick={() => removeLine(line.id)}>
                    <Trash2 size={16} />
                  </IconButton>
                </div>
                <div style={{ display: "grid", gridTemplateColumns: isMobile ? "1fr" : "repeat(2, minmax(0, 1fr))", gap: 10 }}>
                  <div>
                    <label style={labelStyle()}>デザイン名</label>
                    <select value={line.designId} onChange={(e) => updateLine(line.id, "designId", e.target.value)} style={inputStyle(compact)}>
                      <option value="">選択してください</option>
                      {designs.map((design) => <option key={design.id} value={design.id}>{design.name}</option>)}
                    </select>
                  </div>
                  <div>
                    <label style={labelStyle()}>Tシャツカラー</label>
                    <select value={line.shirtCode} onChange={(e) => updateLine(line.id, "shirtCode", e.target.value)} style={inputStyle(compact)}>
                      <option value="">選択してください</option>
                      {shirts.map((shirt) => <option key={shirt.code} value={shirt.code}>{shirt.code} / {shirt.name}</option>)}
                    </select>
                  </div>
                  <div>
                    <label style={labelStyle()}>インクカラー</label>
                    <input
                      value={line.inkColor}
                      onChange={(e) => updateLine(line.id, "inkColor", e.target.value)}
                      style={{ ...inputStyle(compact), background: inkFieldTint }}
                      placeholder="インク名"
                    />
                  </div>
                  <div>
                    <label style={labelStyle()}>サイズ</label>
                    <select value={line.fit} onChange={(e) => updateLine(line.id, "fit", e.target.value)} style={inputStyle(compact)}>
                      {ALL_SIZES.map((size) => <option key={size} value={size}>{size}</option>)}
                    </select>
                  </div>
                  <div>
                    <label style={labelStyle()}>枚数</label>
                    <input type="number" min="1" value={line.qty} onChange={(e) => updateLine(line.id, "qty", e.target.value)} style={inputStyle(compact)} />
                  </div>
                  <div>
                    <label style={labelStyle()}>単価</label>
                    <div style={{ ...inputStyle(compact), background: "#fafaf9", display: "flex", alignItems: "center", fontWeight: 700 }}>¥3,800</div>
                  </div>
                  <div>
                    <label style={labelStyle()}>金額</label>
                    <div style={{ ...inputStyle(compact), background: "#fafaf9", display: "flex", alignItems: "center", fontWeight: 700 }}>{formatYen(amount)}</div>
                  </div>
                  <div style={{ gridColumn: isMobile ? "auto" : "1 / -1" }}>
                    <label style={labelStyle()}>行メモ</label>
                    <input value={line.memo} onChange={(e) => updateLine(line.id, "memo", e.target.value)} style={inputStyle(compact)} />
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        <div style={{ display: "flex", justifyContent: "space-between", gap: 8, flexWrap: "wrap", marginBottom: 18 }}>
          <button type="button" style={buttonStyle(false, compact)} onClick={addLine}>明細を追加</button>
          <button type="button" style={buttonStyle(false, compact)} onClick={startNew}>新規発注書</button>
        </div>

        <div style={{ display: "grid", gap: 8, marginBottom: 16 }}>
          <div style={{ ...inputStyle(compact), background: "#fafaf9", display: "flex", justifyContent: "space-between", alignItems: "center", fontWeight: 700 }}><span>小計</span><span>{formatYen(subtotal)}</span></div>
          <div style={{ ...inputStyle(compact), background: "#f5f5f4", display: "flex", justifyContent: "space-between", alignItems: "center", fontWeight: 800 }}><span>合計</span><span>{formatYen(total)}</span></div>
        </div>

        <div>
          <label style={labelStyle()}>備考</label>
          <textarea value={draft.note} onChange={(e) => updateField("note", e.target.value)} style={{ ...inputStyle(compact), minHeight: 110, resize: "vertical" }} />
        </div>
      </div>

      <div style={panelStyle(compact)}>
        <div style={{ fontWeight: 800, fontSize: 18, marginBottom: 10 }}>保存済み発注書</div>
        <div style={{ display: "grid", gap: 8 }}>
          {savedOrders.length === 0 && <div style={{ fontSize: 13, color: "#78716c" }}>まだ保存された発注書はありません。</div>}
          {savedOrders.map((item) => (
            <div key={item.id} style={{ border: "1px solid #e7e5e4", borderRadius: 14, padding: 12, display: "grid", gap: 8 }}>
              <div style={{ fontWeight: 800 }}>"発注書"</div>
              <div style={{ fontSize: 12, color: "#78716c" }}>{item.customerName || "お客様名未入力"} / {item.orderDate || "日付未入力"}</div>
              <div style={{ fontSize: 12, color: "#57534e" }}>明細 {item.lines?.length || 0} 件</div>
              <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
                <button type="button" style={buttonStyle(false, compact)} onClick={() => loadDraft(item)}>読み込む</button>
                <button type="button" style={{ ...buttonStyle(false, compact), border: "1px solid #fca5a5", background: "#fff5f5" }} onClick={() => deleteDraft(item.id)}>削除</button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

function buildFavoritePreviewDataUrl(canvas, width = 220) {
  if (!canvas) return "";
  const scale = width / canvas.width;
  const targetW = Math.max(120, Math.round(canvas.width * scale));
  const targetH = Math.max(120, Math.round(canvas.height * scale));
  const thumb = document.createElement("canvas");
  thumb.width = targetW;
  thumb.height = targetH;
  const ctx = thumb.getContext("2d");
  if (!ctx) return "";
  ctx.fillStyle = "#f5f5f4";
  ctx.fillRect(0, 0, thumb.width, thumb.height);
  ctx.drawImage(canvas, 0, 0, thumb.width, thumb.height);
  return thumb.toDataURL("image/jpeg", 0.82);
}

function loadImageForPreview(src) {
  return new Promise((resolve, reject) => {
    if (!src) {
      reject(new Error("image src missing"));
      return;
    }
    const img = new Image();
    img.crossOrigin = "anonymous";
    img.onload = () => resolve(img);
    img.onerror = () => reject(new Error(`image load failed: ${src}`));
    img.src = src;
  });
}

function hexToRgba(hex, alpha = 0.12) {
  if (!hex) return `rgba(0,0,0,${alpha})`;
  let value = String(hex).trim().replace('#', '');
  if (value.length === 3) value = value.split('').map((ch) => ch + ch).join('');
  if (value.length !== 6) return `rgba(0,0,0,${alpha})`;
  const r = parseInt(value.slice(0, 2), 16);
  const g = parseInt(value.slice(2, 4), 16);
  const b = parseInt(value.slice(4, 6), 16);
  return `rgba(${r}, ${g}, ${b}, ${alpha})`;
}

function getInkPresetByValue(value, explicitHex = "") {
  const normalized = String(value || '').trim().toLowerCase();
  const normalizedHex = String(explicitHex || '').trim().toLowerCase();
  if (normalizedHex) {
    const byHex = inkPresets.find((ink) => ink.color.trim().toLowerCase() === normalizedHex);
    if (byHex) return byHex;
  }
  if (!normalized) return null;
  return (
    inkPresets.find((ink) => ink.name.trim().toLowerCase() === normalized) ||
    inkPresets.find((ink) => ink.id.trim().toLowerCase() === normalized) ||
    inkPresets.find((ink) => ink.color.trim().toLowerCase() === normalized) ||
    null
  );
}

function clamp(value, min, max) {
  return Math.max(min, Math.min(max, value));
}

function lerp(a, b, t) {
  return a + (b - a) * t;
}

function getBodyLengthCm(sizeKey) {
  return sizeSpec[sizeKey]?.bodyLengthCm ?? sizeSpec[BASE_PRINT_SIZE].bodyLengthCm;
}

function getBaseVariantForShirt(shirt) {
  if (!shirt?.variants) return null;
  return shirt.variants.M || shirt.variants.S || shirt.variants.XS || Object.values(shirt.variants)[0] || null;
}

function getShirtScale(sizeKey) {
  const base = getBodyLengthCm(BASE_PRINT_SIZE);
  const current = getBodyLengthCm(sizeKey);
  return current / base;
}

function getCanvasPoint(clientX, clientY, canvas) {
  const rect = canvas.getBoundingClientRect();
  return {
    x: ((clientX - rect.left) / rect.width) * canvas.width,
    y: ((clientY - rect.top) / rect.height) * canvas.height,
  };
}

function drawSelectionBox(ctx, info) {
  if (!info) return;

  const { designX, designY, designW, designH } = info;
  const hx = designX + designW;
  const hy = designY + designH;
  const zoom = info.zoom || 1;
  const half = HANDLE_SIZE / 2;

  ctx.save();
  ctx.strokeStyle = "#0ea5e9";
  ctx.lineWidth = 2 / zoom;
  ctx.setLineDash([]);
  ctx.strokeRect(designX, designY, designW, designH);

  ctx.fillStyle = "#ffffff";
  ctx.strokeStyle = "#0ea5e9";
  ctx.lineWidth = 2 / zoom;
  ctx.beginPath();
  ctx.rect(hx - half / zoom, hy - half / zoom, HANDLE_SIZE / zoom, HANDLE_SIZE / zoom);
  ctx.fill();
  ctx.stroke();
  ctx.restore();
}

function hitResizeHandle(point, info) {
  if (!info) return false;
  const zoom = info.zoom || 1;
  const hx = info.designX + info.designW;
  const hy = info.designY + info.designH;
  const half = (HANDLE_SIZE / 2) / zoom;

  return (
    point.x >= hx - half &&
    point.x <= hx + half &&
    point.y >= hy - half &&
    point.y <= hy + half
  );
}

function hitDesignBody(point, info) {
  if (!info) return false;
  return (
    point.x >= info.designX &&
    point.x <= info.designX + info.designW &&
    point.y >= info.designY &&
    point.y <= info.designY + info.designH
  );
}

function normalizeFace(face, fallbackFace) {
  return {
    x: typeof face?.x === "number" ? face.x : fallbackFace.x,
    y: typeof face?.y === "number" ? face.y : fallbackFace.y,
    widthCm:
      typeof face?.widthCm === "number"
        ? face.widthCm
        : typeof face?.width === "number"
        ? Number(((getBodyLengthCm(BASE_PRINT_SIZE) * face.width) / 100).toFixed(2))
        : fallbackFace.widthCm,
    flipX: typeof face?.flipX === "boolean" ? face.flipX : fallbackFace.flipX,
  };
}

function getAllowedStoredFaceSizes(saved, designId, side) {
  const bySide = saved?.[designId]?.[side] || {};
  return Object.keys(bySide)
    .filter((size) => sizeSpec[size] && EDITABLE_SIZES.includes(size))
    .sort((a, b) => getBodyLengthCm(a) - getBodyLengthCm(b));
}

function interpolateFacePlacement(saved, designId, side, targetSize) {
  const defaults = getInitialPlacement(designId);
  const fallbackFace = defaults?.[side] ?? {
    x: 50,
    y: 30,
    widthCm: 28,
    flipX: false,
  };

  const bySide = saved?.[designId]?.[side] || {};
  const mFace = bySide.M ? normalizeFace(bySide.M, fallbackFace) : normalizeFace(fallbackFace, fallbackFace);
  const direct = EDITABLE_SIZES.includes(targetSize) ? bySide[targetSize] : null;

  if (direct) {
    const face = normalizeFace(direct, fallbackFace);
    return {
      x: face.x,
      y: face.y,
      widthCm: mFace.widthCm,
      flipX: face.flipX,
    };
  }

  const sizes = getAllowedStoredFaceSizes(saved, designId, side);

  if (sizes.length === 0) {
    const face = normalizeFace(fallbackFace, fallbackFace);
    return {
      x: face.x,
      y: face.y,
      widthCm: mFace.widthCm,
      flipX: face.flipX,
    };
  }

  if (sizes.length === 1) {
    const only = normalizeFace(bySide[sizes[0]], fallbackFace);
    return {
      x: only.x,
      y: only.y,
      widthCm: mFace.widthCm,
      flipX: only.flipX,
    };
  }

  const targetCm = getBodyLengthCm(targetSize);

  let lowerSize = null;
  let upperSize = null;

  for (const size of sizes) {
    const cm = getBodyLengthCm(size);
    if (cm <= targetCm) lowerSize = size;
    if (cm >= targetCm) {
      upperSize = size;
      break;
    }
  }

  if (!lowerSize) {
    const upper = normalizeFace(bySide[upperSize], fallbackFace);
    return {
      x: upper.x,
      y: upper.y,
      widthCm: mFace.widthCm,
      flipX: upper.flipX,
    };
  }

  if (!upperSize) {
    const lower = normalizeFace(bySide[lowerSize], fallbackFace);
    return {
      x: lower.x,
      y: lower.y,
      widthCm: mFace.widthCm,
      flipX: lower.flipX,
    };
  }

  if (lowerSize === upperSize) {
    const same = normalizeFace(bySide[lowerSize], fallbackFace);
    return {
      x: same.x,
      y: same.y,
      widthCm: mFace.widthCm,
      flipX: same.flipX,
    };
  }

  const lower = normalizeFace(bySide[lowerSize], fallbackFace);
  const upper = normalizeFace(bySide[upperSize], fallbackFace);

  const lowerCm = getBodyLengthCm(lowerSize);
  const upperCm = getBodyLengthCm(upperSize);
  const t = (targetCm - lowerCm) / (upperCm - lowerCm);

  return {
    x: lerp(lower.x, upper.x, t),
    y: lerp(lower.y, upper.y, t),
    widthCm: mFace.widthCm,
    flipX: t < 0.5 ? lower.flipX : upper.flipX,
  };
}

function buildPlacementState(saved, designId, targetSize) {
  return {
    front: interpolateFacePlacement(saved, designId, "front", targetSize),
    back: interpolateFacePlacement(saved, designId, "back", targetSize),
  };
}

function buildPlacementStateFromDesignsData(designId, targetSize) {
  const savedBasePlacements = getSavedBasePlacements(designId) ?? {};
  return buildPlacementState({ [designId]: savedBasePlacements }, designId, targetSize);
}

function buildSavedMapFromDesignsData() {
  const map = {};
  for (const design of designs) {
    const designId = design?.id;
    if (!designId) continue;
    const defaults = getInitialPlacement(designId) ?? {};
    const savedBases = getSavedBasePlacements(designId) ?? {};

    const frontM = roundPlacement(savedBases?.front?.M ?? defaults?.front);
    const backM = roundPlacement(savedBases?.back?.M ?? defaults?.back);

    map[designId] = {
      front: {
        "120": { ...roundPlacement(savedBases?.front?.["120"] ?? defaults?.front), widthCm: frontM.widthCm },
        M: { ...frontM },
        XXL: { ...roundPlacement(savedBases?.front?.XXL ?? defaults?.front), widthCm: frontM.widthCm },
      },
      back: {
        "120": { ...roundPlacement(savedBases?.back?.["120"] ?? defaults?.back), widthCm: backM.widthCm },
        M: { ...backM },
        XXL: { ...roundPlacement(savedBases?.back?.XXL ?? defaults?.back), widthCm: backM.widthCm },
      },
    };
  }
  return map;
}

function ShirtPicker({ shirts, shirtCode, setShirtCode, side, compact }) {
  const [open, setOpen] = useState(false);
  const [query, setQuery] = useState("");
  const wrapRef = useRef(null);

  const selectedShirt = shirts.find((shirt) => shirt.code === shirtCode) ?? shirts[0];

  const filteredShirts = useMemo(() => {
    const q = query.trim().toLowerCase();
    if (!q) return shirts;
    return shirts.filter((shirt) => {
      const text = `${shirt.code} ${shirt.name || ""}`.toLowerCase();
      return text.includes(q);
    });
  }, [query, shirts]);

  useEffect(() => {
    const onDown = (e) => {
      if (!wrapRef.current?.contains(e.target)) setOpen(false);
    };
    document.addEventListener("mousedown", onDown);
    return () => document.removeEventListener("mousedown", onDown);
  }, []);

  const getThumb = (shirt) => {
    const baseVariant = getBaseVariantForShirt(shirt);
    return side === "front" ? baseVariant?.front : baseVariant?.back;
  };

  return (
    <div ref={wrapRef} style={{ position: "relative", minWidth: 0 }}>
      <button
        type="button"
        style={{
          ...inputStyle(compact),
          display: "flex",
          alignItems: "center",
          gap: 12,
          background: "#fff",
          textAlign: "left",
          cursor: "pointer",
        }}
        onClick={() => setOpen((v) => !v)}
      >
        <img
          src={getThumb(selectedShirt)}
          alt={selectedShirt?.code || "shirt"}
          style={{
            width: compact ? 40 : 44,
            height: compact ? 40 : 44,
            objectFit: "cover",
            borderRadius: 10,
            border: "1px solid #d6d3d1",
            background: "#fafaf9",
            flexShrink: 0,
          }}
        />
        <div style={{ flex: 1, minWidth: 0 }}>
          <div style={{ fontWeight: 800, fontSize: compact ? 13 : 14 }}>{selectedShirt?.code || "-"}</div>
          <div style={{ fontSize: 11, color: "#78716c" }}>{selectedShirt?.name || "Tシャツカラー"}</div>
        </div>
        <div style={{ fontSize: 11, color: "#57534e" }}>▼</div>
      </button>

      {open && (
        <div
          style={{
            position: "absolute",
            top: "calc(100% + 8px)",
            left: 0,
            right: 0,
            zIndex: 20,
            background: "#fff",
            border: "1px solid #d6d3d1",
            borderRadius: 16,
            boxShadow: "0 12px 32px rgba(0,0,0,0.12)",
            padding: 10,
            minWidth: 0,
          }}
        >
          <input
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="色コード / 色名で検索"
            style={{ ...inputStyle(compact), marginBottom: 10 }}
          />

          <div
            style={{
              maxHeight: 320,
              overflowY: "auto",
              display: "grid",
              gap: 8,
            }}
          >
            {filteredShirts.map((shirt) => (
              <button
                key={shirt.code}
                type="button"
                onClick={() => {
                  setShirtCode(shirt.code);
                  setOpen(false);
                }}
                style={{
                  border: shirt.code === shirtCode ? "2px solid #111" : "1px solid #d6d3d1",
                  background: "#fff",
                  borderRadius: 12,
                  padding: 8,
                  cursor: "pointer",
                  display: "flex",
                  alignItems: "center",
                  gap: 8,
                  textAlign: "left",
                  minWidth: 0,
                }}
              >
                <img
                  src={getThumb(shirt)}
                  alt={shirt.code}
                  style={{
                    width: compact ? 38 : 42,
                    height: compact ? 38 : 42,
                    objectFit: "cover",
                    borderRadius: 10,
                    border: "1px solid #d6d3d1",
                    background: "#fafaf9",
                    flexShrink: 0,
                  }}
                />
                <div style={{ minWidth: 0 }}>
                  <div style={{ fontWeight: 800, fontSize: compact ? 13 : 14 }}>{shirt.code}</div>
                  <div style={{ fontSize: 12, color: "#78716c" }}>{shirt.name || "Tシャツカラー"}</div>
                </div>
              </button>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

function DesignPicker({ designs, designId, setDesignId, setIsSwitchingDesign, columns = 3, compact = false, isMobile = false }) {
  const thumbSide = "back";
  const [hoveredId, setHoveredId] = useState(null);

  if (isMobile) {
    return (
      <div style={{ minWidth: 0, maxWidth: "100%", overflow: "hidden" }}>
        <div
          style={{
            display: "flex",
            gap: compact ? 8 : 10,
            overflowX: "auto",
            overflowY: "hidden",
            width: "100%",
            maxWidth: "100%",
            paddingBottom: 4,
            WebkitOverflowScrolling: "touch",
            scrollbarWidth: "thin",
          }}
        >
          {designs.map((design) => {
            const thumbSrc = thumbSide === "front" ? design.front || design.back : design.back || design.front;
            const active = design.id === designId;
            const hovered = hoveredId === design.id;

            return (
              <button
                key={design.id}
                type="button"
                onMouseEnter={() => setHoveredId(design.id)}
                onMouseLeave={() => setHoveredId((prev) => (prev === design.id ? null : prev))}
                onFocus={() => setHoveredId(design.id)}
                onBlur={() => setHoveredId((prev) => (prev === design.id ? null : prev))}
                onClick={() => {
                  if (design.id === designId) return;
                  setIsSwitchingDesign(true);
                  setDesignId(design.id);
                }}
                style={{
                  position: "relative",
                  flex: "0 0 auto",
                  width: compact ? 112 : 126,
                  minWidth: compact ? 112 : 126,
                  maxWidth: compact ? 112 : 126,
                  border: active ? "2px solid #111" : "1px solid #d6d3d1",
                  background: "#fff",
                  borderRadius: compact ? 10 : 12,
                  padding: compact ? 5 : 6,
                  cursor: "pointer",
                  display: "block",
                  boxShadow: active ? "0 4px 12px rgba(0,0,0,0.08)" : "none",
                  overflow: "hidden",
                }}
              >
                <div
                  style={{
                    width: "100%",
                    aspectRatio: "1 / 1",
                    borderRadius: compact ? 8 : 9,
                    border: active ? "1px solid #d6d3d1" : "1px solid #e7e5e4",
                    background: "#fafaf9",
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                    overflow: "hidden",
                  }}
                >
                  {thumbSrc ? (
                    <img
                      src={thumbSrc}
                      alt={design.name}
                      style={{
                        width: compact ? "94%" : "92%",
                        height: compact ? "94%" : "92%",
                        objectFit: "contain",
                        display: "block",
                        transition: "transform 0.14s ease",
                        transform: hovered ? "scale(1.03)" : "scale(1)",
                      }}
                    />
                  ) : (
                    <div style={{ fontSize: 11, color: "#a8a29e" }}>no image</div>
                  )}
                </div>

                <div
                  style={{
                    position: "absolute",
                    left: 6,
                    right: 6,
                    bottom: 6,
                    padding: compact ? "5px 6px" : "6px 7px",
                    borderRadius: 8,
                    background: active ? "rgba(17,17,17,0.92)" : "rgba(17,17,17,0.82)",
                    color: "#fff",
                    fontSize: compact ? 10 : 10.5,
                    fontWeight: 700,
                    lineHeight: 1.25,
                    textAlign: "left",
                    opacity: hovered || active ? 1 : 0,
                    transform: hovered || active ? "translateY(0)" : "translateY(4px)",
                    transition: "opacity 0.14s ease, transform 0.14s ease",
                    pointerEvents: "none",
                    whiteSpace: "normal",
                    wordBreak: "break-word",
                  }}
                >
                  {design.name}
                </div>
              </button>
            );
          })}
        </div>
      </div>
    );
  }

  return (
    <div
      style={{
        display: "grid",
        gridTemplateColumns: `repeat(${columns}, minmax(0, 1fr))`,
        gap: compact ? 6 : 8,
        minWidth: 0,
      }}
    >
      {designs.map((design) => {
        const thumbSrc = thumbSide === "front" ? design.front || design.back : design.back || design.front;
        const active = design.id === designId;
        const hovered = hoveredId === design.id;

        return (
          <button
            key={design.id}
            type="button"
            onMouseEnter={() => setHoveredId(design.id)}
            onMouseLeave={() => setHoveredId((prev) => (prev === design.id ? null : prev))}
            onFocus={() => setHoveredId(design.id)}
            onBlur={() => setHoveredId((prev) => (prev === design.id ? null : prev))}
            onClick={() => {
              if (design.id === designId) return;
              setIsSwitchingDesign(true);
              setDesignId(design.id);
            }}
            style={{
              position: "relative",
              border: active ? "2px solid #111" : "1px solid #d6d3d1",
              background: "#fff",
              borderRadius: compact ? 10 : 12,
              padding: compact ? 5 : 6,
              cursor: "pointer",
              display: "block",
              boxShadow: active ? "0 4px 12px rgba(0,0,0,0.08)" : "none",
              overflow: "hidden",
              minWidth: 0,
            }}
          >
            <div
              style={{
                width: "100%",
                aspectRatio: "1 / 1",
                borderRadius: compact ? 8 : 9,
                border: active ? "1px solid #d6d3d1" : "1px solid #e7e5e4",
                background: "#fafaf9",
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                overflow: "hidden",
              }}
            >
              {thumbSrc ? (
                <img
                  src={thumbSrc}
                  alt={design.name}
                  style={{
                    width: compact ? "94%" : "92%",
                    height: compact ? "94%" : "92%",
                    objectFit: "contain",
                    display: "block",
                    transition: "transform 0.14s ease",
                    transform: hovered ? "scale(1.03)" : "scale(1)",
                  }}
                />
              ) : (
                <div style={{ fontSize: 11, color: "#a8a29e" }}>no image</div>
              )}
            </div>

            <div
              style={{
                position: "absolute",
                left: 6,
                right: 6,
                bottom: 6,
                padding: compact ? "5px 6px" : "6px 7px",
                borderRadius: 8,
                background: active ? "rgba(17,17,17,0.92)" : "rgba(17,17,17,0.82)",
                color: "#fff",
                fontSize: compact ? 10 : 10.5,
                fontWeight: 700,
                lineHeight: 1.25,
                textAlign: "left",
                opacity: hovered || active ? 1 : 0,
                transform: hovered || active ? "translateY(0)" : "translateY(4px)",
                transition: "opacity 0.14s ease, transform 0.14s ease",
                pointerEvents: "none",
                whiteSpace: "normal",
                wordBreak: "break-word",
              }}
            >
              {design.name}
            </div>
          </button>
        );
      })}
    </div>
  );
}

function SizeButton({ size, active, editable, onClick, compact = false }) {
  return (
    <button
      type="button"
      style={{
        ...buttonStyle(active, compact),
        position: "relative",
        paddingTop: compact ? 9 : 10,
        paddingBottom: compact ? 7 : 8,
        paddingLeft: compact ? 8 : 10,
        paddingRight: compact ? 8 : 10,
        minHeight: compact ? 36 : 40,
        fontSize: compact ? 12 : 13,
        borderRadius: 10,
      }}
      onClick={onClick}
    >
      {editable && (
        <span
          style={{
            position: "absolute",
            top: 3,
            right: 6,
            fontSize: 9,
            lineHeight: 1,
            color: active ? "#111" : "#78716c",
          }}
        >
          ●
        </span>
      )}
      {size}
    </button>
  );
}

function SectionHeader({ title, open, onToggle, collapsible, isMobile, fontSize, rightElement = null }) {
  return (
    <div
      onClick={collapsible ? onToggle : undefined}
      style={{
        fontWeight: 800,
        fontSize,
        marginBottom: open ? 14 : 0,
        display: "flex",
        justifyContent: "space-between",
        alignItems: "center",
        gap: 8,
        cursor: collapsible ? "pointer" : "default",
        userSelect: "none",
      }}
    >
      <span>{title}</span>
      <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
        {rightElement}
        {isMobile && collapsible && <span style={{ fontSize: 18, lineHeight: 1 }}>{open ? "−" : "＋"}</span>}
      </div>
    </div>
  );
}

export default function App() {
  const canvasRef = useRef(null);
  const wrapRef = useRef(null);
  const renderInfoRef = useRef(null);

  const dragRef = useRef({
    active: false,
    mode: null,
    pointerId: null,
    startCanvasX: 0,
    startCanvasY: 0,
    startPlacementX: 0,
    startPlacementY: 0,
    startWidthCm: 0,
  });

  const panRef = useRef({
    active: false,
    pointerId: null,
    startX: 0,
    startY: 0,
    startOffsetX: 0,
    startOffsetY: 0,
  });

  const touchRef = useRef({
    active: false,
    mode: null,
    startDistance: 0,
    startZoom: 1,
    startPanX: 0,
    startPanY: 0,
    startCenterX: 0,
    startCenterY: 0,
  });

  const [zoom, setZoom] = useState(1);
  const [pan, setPan] = useState({ x: 0, y: 0 });
  const [side, setSide] = useState("front");
  const [shirtCode, setShirtCode] = useState(shirts[0]?.code || "001");
  const [fit, setFit] = useState("M");
  const [designId, setDesignId] = useState(designs[0]?.id || "");
  const [inkColor, setInkColor] = useState("#201010");
  const [svgCache, setSvgCache] = useState({});
  const [canvasSize, setCanvasSize] = useState({ width: 900, height: 900 });
  const [status, setStatus] = useState("画像とSVGを読み込み中...");
  const [isDesignSelected, setIsDesignSelected] = useState(false);
  const [hoverMode, setHoverMode] = useState(null);
  const [isShiftPressed, setIsShiftPressed] = useState(false);
  const [isSwitchingDesign, setIsSwitchingDesign] = useState(false);
  const [exportText, setExportText] = useState("");
  const [favorites, setFavorites] = useState(() => loadFavorites());
  const [appView, setAppView] = useState("maker");
  const [orderDraft, setOrderDraft] = useState(() => createEmptyOrderDraft());
  const [savedOrders, setSavedOrders] = useState(() => loadOrderDrafts());
  const [interactionMode, setInteractionMode] = useState("pan");
  const [isEditMode, setIsEditMode] = useState(false);
  const [viewportWidth, setViewportWidth] = useState(() => (typeof window !== "undefined" ? window.innerWidth : 1440));
  const [isDesignAdjustAuthed, setIsDesignAdjustAuthed] = useState(() => loadDesignAdjustAuth());

  const [openSections, setOpenSections] = useState({
    shirtSettings: true,
    inkColor: true,
    designPicker: true,
    designAdjust: false,
  });

  const [placement, setPlacement] = useState(() => {
    const firstDesignId = designs[0]?.id || "";
    return buildPlacementStateFromDesignsData(firstDesignId, "M");
  });

  useEffect(() => {
    saveFavoritesToStorage(favorites);
  }, [favorites]);

  useEffect(() => {
    saveOrderDraftsToStorage(savedOrders);
  }, [savedOrders]);

  useEffect(() => {
    saveDesignAdjustAuth(isDesignAdjustAuthed);
  }, [isDesignAdjustAuthed]);

  const hasSkippedInitialPlacementReloadRef = useRef(false);
  const sessionPlacementsRef = useRef({});

  const isMobile = viewportWidth < 700;
  const isTablet = viewportWidth < 980;
  const compact = viewportWidth < 560;
  const isTouchCapable = typeof navigator !== "undefined" && navigator.maxTouchPoints > 0;
  const previewDpr = useMemo(() => {
    if (typeof window === "undefined") return 1;
    const raw = window.devicePixelRatio || 1;
    return Math.max(1, Math.min(raw, isMobile ? 2.5 : 2));
  }, [isMobile]);
  const layoutColumns = isTablet ? "1fr" : "minmax(0, 1fr) minmax(340px, 420px)";
  const sizeColumns = isMobile ? 4 : 5;
  const designColumns = isMobile ? 2 : isTablet ? 2 : 3;

  const canEditCurrentSize = EDITABLE_SIZES.includes(fit);
  const canEditActive = canEditCurrentSize && isEditMode;

  const selectedShirt = useMemo(() => shirts.find((s) => s.code === shirtCode) ?? shirts[0], [shirtCode]);
  const selectedDesign = useMemo(() => designs.find((d) => d.id === designId) ?? designs[0], [designId]);
  const currentBaseOrderUrl = selectedDesign?.baseOrderUrl?.trim?.() || "";
  const hasBaseOrderUrl = Boolean(currentBaseOrderUrl);
  const baseVariant = useMemo(() => getBaseVariantForShirt(selectedShirt), [selectedShirt]);

  const shirtSrc = side === "front" ? baseVariant?.front : baseVariant?.back;
  const activeSvgRaw = svgCache[designId]?.[side] || "";
  const currentPlacement = placement?.[side];

  const svgDataUrl = useMemo(() => {
    if (!activeSvgRaw) return "";
    const recolored = forceSingleColorSvg(activeSvgRaw, inkColor);
    return `data:image/svg+xml;charset=utf-8,${encodeURIComponent(recolored)}`;
  }, [activeSvgRaw, inkColor]);

  const currentSelectionLabel = `${selectedDesign?.name || designId || "デザイン未選択"} / ${shirtCode || "-"} / ${fit || "-"} / ${shirts.find((s) => s.code === shirtCode)?.name || ""}`.trim();

  const selectedInkName =
    inkPresets.find((ink) => ink.color.toLowerCase() === inkColor.toLowerCase())?.name ||
    `カスタムカラー ${inkColor}`;

  const promptDesignAdjustPassword = () => {
    const input = window.prompt("デザイン調整用パスワードを入力してください");
    if (input == null) {
      setStatus("デザイン調整の認証をキャンセルしました");
      return false;
    }
    if (input === DESIGN_ADJUST_PASSWORD) {
      setIsDesignAdjustAuthed(true);
      setStatus("デザイン調整を認証しました");
      return true;
    }
    window.alert("パスワードが違います");
    setStatus("デザイン調整の認証に失敗しました");
    return false;
  };

  const ensureDesignAdjustAuth = () => {
    if (isDesignAdjustAuthed) return true;
    return promptDesignAdjustPassword();
  };

  const addCurrentSelectionToOrder = () => {
    const nextLine = createEmptyOrderLine({
      designId: designId || "",
      shirtCode: shirtCode || "",
      inkColor: selectedInkName || "",
      inkColorHex: inkColor || "",
      fit: fit || "M",
      qty: 1,
      unitPrice: 3800,
      memo: "",
    });

    setOrderDraft((prev) => {
      const lines = Array.isArray(prev.lines) ? [...prev.lines] : [];
      const first = lines[0];
      const hasOnlyEmptyStarter =
        lines.length === 1 &&
        first &&
        !first.designId &&
        !first.shirtCode &&
        !first.inkColor &&
        !first.inkColorHex &&
        (!first.fit || first.fit === "M") &&
        Number(first.qty ?? 1) === 1 &&
        Number(first.unitPrice ?? 3800) === 3800 &&
        !first.memo;

      return {
        ...prev,
        lines: hasOnlyEmptyStarter ? [nextLine] : [...lines, nextLine],
      };
    });
  };

  const openOrderWithCurrentSelection = () => {
    addCurrentSelectionToOrder();
    setAppView("order");
  };

  const openBaseOrderPage = () => {
    if (typeof window === "undefined") return;

    const url = currentBaseOrderUrl;
    if (!url) {
      setStatus(`このデザインはまだBASE注文ページが設定されていません: ${selectedDesign?.name || designId}`);
      return;
    }

    window.open(url, "_blank", "noopener,noreferrer");
  };

  const getPlacementStateForView = (nextDesignId, nextFit) => {
    const sessionMap = sessionPlacementsRef.current || {};
    if (sessionMap?.[nextDesignId]) {
      return buildPlacementState(sessionMap, nextDesignId, nextFit);
    }
    return buildPlacementStateFromDesignsData(nextDesignId, nextFit);
  };

  useEffect(() => {
    const nextSessionMap = buildSavedMapFromDesignsData();
    sessionPlacementsRef.current = nextSessionMap;
    savePlacementsToStorage(nextSessionMap);
  }, []);

  useEffect(() => {
    const onResize = () => setViewportWidth(window.innerWidth);
    window.addEventListener("resize", onResize);
    return () => window.removeEventListener("resize", onResize);
  }, []);

  useEffect(() => {
    if (isMobile) {
      setOpenSections({
        shirtSettings: false,
        inkColor: false,
        designPicker: true,
        designAdjust: false,
      });
    } else {
      setOpenSections({
        shirtSettings: true,
        inkColor: true,
        designPicker: true,
        designAdjust: false,
      });
    }
  }, [isMobile]);

  useEffect(() => {
    setInteractionMode(isEditMode ? "design" : "pan");
  }, [isEditMode]);

  useEffect(() => {
    const onKeyDown = (e) => {
      if (e.key === "Shift") setIsShiftPressed(true);
    };
    const onKeyUp = (e) => {
      if (e.key === "Shift") setIsShiftPressed(false);
    };

    window.addEventListener("keydown", onKeyDown);
    window.addEventListener("keyup", onKeyUp);

    return () => {
      window.removeEventListener("keydown", onKeyDown);
      window.removeEventListener("keyup", onKeyUp);
    };
  }, []);

  useEffect(() => {
    if (!isTouchCapable) return;

    const wrap = wrapRef.current;
    if (!wrap) return;

    const handleNativeTouchStart = (e) => {
      if (e.touches.length !== 2) return;
      const [t1, t2] = e.touches;
      stopSingleTouchInteraction();
      setIsDesignSelected(false);
      touchRef.current.active = true;
      touchRef.current.mode = "pinch";
      touchRef.current.startDistance = getTouchDistance(t1, t2);
      touchRef.current.startZoom = zoom;
      e.preventDefault();
      e.stopPropagation();
    };

    const handleNativeTouchMove = (e) => {
      if (e.touches.length !== 2) return;
      const [t1, t2] = e.touches;
      const currentDistance = getTouchDistance(t1, t2);

      if (!touchRef.current.active || touchRef.current.mode !== "pinch" || touchRef.current.startDistance <= 0) {
        stopSingleTouchInteraction();
        setIsDesignSelected(false);
        touchRef.current.active = true;
        touchRef.current.mode = "pinch";
        touchRef.current.startDistance = currentDistance;
        touchRef.current.startZoom = zoom;
        e.preventDefault();
        e.stopPropagation();
        return;
      }

      const scale = currentDistance / touchRef.current.startDistance;
      const nextZoom = clamp(touchRef.current.startZoom * scale, MIN_ZOOM, MAX_ZOOM);
      setZoom((prev) => (Math.abs(prev - nextZoom) < 0.0001 ? prev : nextZoom));
      e.preventDefault();
      e.stopPropagation();
    };

    const handleNativeTouchEnd = (e) => {
      if (touchRef.current.mode !== "pinch") return;
      if (e.touches.length < 2) {
        touchRef.current.active = false;
        touchRef.current.mode = null;
        touchRef.current.startDistance = 0;
        touchRef.current.startZoom = zoom;
        stopSingleTouchInteraction();
        e.preventDefault();
        e.stopPropagation();
      }
    };

    wrap.addEventListener("touchstart", handleNativeTouchStart, { passive: false, capture: true });
    wrap.addEventListener("touchmove", handleNativeTouchMove, { passive: false, capture: true });
    wrap.addEventListener("touchend", handleNativeTouchEnd, { passive: false, capture: true });
    wrap.addEventListener("touchcancel", handleNativeTouchEnd, { passive: false, capture: true });

    return () => {
      wrap.removeEventListener("touchstart", handleNativeTouchStart, true);
      wrap.removeEventListener("touchmove", handleNativeTouchMove, true);
      wrap.removeEventListener("touchend", handleNativeTouchEnd, true);
      wrap.removeEventListener("touchcancel", handleNativeTouchEnd, true);
    };
  }, [isTouchCapable, zoom]);

  useEffect(() => {
    if (!isTouchCapable) return;

    const wrap = wrapRef.current;
    const canvas = canvasRef.current;
    if (!wrap || !canvas) return;

    const preventMultiTouchDefault = (e) => {
      if (e.touches && e.touches.length >= 2) {
        e.preventDefault();
      }
    };

    const preventGestureDefault = (e) => {
      e.preventDefault();
    };

    wrap.style.touchAction = "none";
    wrap.style.overscrollBehavior = "none";
    canvas.style.touchAction = "none";
    canvas.style.overscrollBehavior = "none";

    wrap.addEventListener("touchstart", preventMultiTouchDefault, { passive: false });
    wrap.addEventListener("touchmove", preventMultiTouchDefault, { passive: false });
    canvas.addEventListener("touchstart", preventMultiTouchDefault, { passive: false });
    canvas.addEventListener("touchmove", preventMultiTouchDefault, { passive: false });

    wrap.addEventListener("gesturestart", preventGestureDefault, { passive: false });
    wrap.addEventListener("gesturechange", preventGestureDefault, { passive: false });
    wrap.addEventListener("gestureend", preventGestureDefault, { passive: false });
    canvas.addEventListener("gesturestart", preventGestureDefault, { passive: false });
    canvas.addEventListener("gesturechange", preventGestureDefault, { passive: false });
    canvas.addEventListener("gestureend", preventGestureDefault, { passive: false });

    return () => {
      wrap.removeEventListener("touchstart", preventMultiTouchDefault);
      wrap.removeEventListener("touchmove", preventMultiTouchDefault);
      canvas.removeEventListener("touchstart", preventMultiTouchDefault);
      canvas.removeEventListener("touchmove", preventMultiTouchDefault);

      wrap.removeEventListener("gesturestart", preventGestureDefault);
      wrap.removeEventListener("gesturechange", preventGestureDefault);
      wrap.removeEventListener("gestureend", preventGestureDefault);
      canvas.removeEventListener("gesturestart", preventGestureDefault);
      canvas.removeEventListener("gesturechange", preventGestureDefault);
      canvas.removeEventListener("gestureend", preventGestureDefault);
    };
  }, [isTouchCapable]);

  useEffect(() => {
    let cancelled = false;

    (async () => {
      try {
        const pending = designs.filter((d) => !svgCache[d.id]);
        if (pending.length === 0) {
          if (!cancelled) setStatus("SVG読み込み完了");
          return;
        }

        const results = await Promise.all(
          pending.map(async (d) => {
            const front = d.front ? await fetchText(d.front) : "";
            const back = d.back ? await fetchText(d.back) : "";
            return { id: d.id, front, back };
          })
        );

        if (!cancelled) {
          setSvgCache((prev) => {
            const next = { ...prev };
            results.forEach((r) => {
              next[r.id] = { front: r.front, back: r.back };
            });
            return next;
          });
          setStatus("SVG読み込み完了");
        }
      } catch {
        if (!cancelled) setStatus("SVGの読み込みに失敗。public/designs を確認してください。");
      }
    })();

    return () => {
      cancelled = true;
    };
  }, [svgCache]);

  useEffect(() => {
    const handleResize = () => {
      const w = wrapRef.current?.clientWidth ?? 900;
      const paddingOffset = isMobile ? 12 : 24;
      const size = Math.max(280, Math.min(isTablet ? 760 : 980, Math.floor(w - paddingOffset)));
      setCanvasSize({ width: size, height: size });
    };

    handleResize();
    window.addEventListener("resize", handleResize);
    return () => window.removeEventListener("resize", handleResize);
  }, [isMobile, isTablet]);

  useEffect(() => {
    if (appView !== "maker") return;
    const sync = () => {
      const w = wrapRef.current?.clientWidth ?? 900;
      const paddingOffset = isMobile ? 12 : 24;
      const size = Math.max(280, Math.min(isTablet ? 760 : 980, Math.floor(w - paddingOffset)));
      setCanvasSize({ width: size, height: size });
      setStatus((prev) => (prev ? prev : "表示を再同期中..."));
    };
    requestAnimationFrame(sync);
  }, [appView, isMobile, isTablet]);

  useEffect(() => {
    if (!designId) return;

    if (!hasSkippedInitialPlacementReloadRef.current) {
      hasSkippedInitialPlacementReloadRef.current = true;
      setIsDesignSelected(false);
      setIsSwitchingDesign(false);
      return;
    }

    const nextPlacement = getPlacementStateForView(designId, fit);
    setPlacement(nextPlacement);
    setIsDesignSelected(false);
    setIsSwitchingDesign(false);
  }, [designId, fit]);

  useEffect(() => {
    if (!designId || !placement) return;
    if (!canEditCurrentSize) return;

    const sessionMap = safeClone(sessionPlacementsRef.current || {});
    if (!sessionMap[designId]) sessionMap[designId] = {};
    if (!sessionMap[designId].front) sessionMap[designId].front = {};
    if (!sessionMap[designId].back) sessionMap[designId].back = {};

    sessionMap[designId].front[fit] = safeClone(placement.front);
    sessionMap[designId].back[fit] = safeClone(placement.back);

    const defaults = getInitialPlacement(designId) || {};
    if (!sessionMap[designId].front.M) sessionMap[designId].front.M = safeClone(defaults.front ?? placement.front);
    if (!sessionMap[designId].back.M) sessionMap[designId].back.M = safeClone(defaults.back ?? placement.back);

    if (typeof placement.front?.widthCm === "number") {
      sessionMap[designId].front.M.widthCm = placement.front.widthCm;
    }
    if (typeof placement.back?.widthCm === "number") {
      sessionMap[designId].back.M.widthCm = placement.back.widthCm;
    }

    sessionPlacementsRef.current = sessionMap;
    savePlacementsToStorage(sessionMap);
  }, [designId, fit, placement, canEditCurrentSize]);

  useEffect(() => {
    if (isSwitchingDesign) return;

    if (!shirtSrc) {
      setStatus(`画像なし: ${selectedShirt?.code || "?"} / ${side}`);
      return;
    }

    if (!svgDataUrl || !canvasRef.current || !currentPlacement) return;

    const canvas = canvasRef.current;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    const shirtImg = new Image();
    const svgImg = new Image();
    shirtImg.crossOrigin = "anonymous";
    svgImg.crossOrigin = "anonymous";

    let shirtLoaded = false;
    let svgLoaded = false;

    const render = () => {
      if (!shirtLoaded || !svgLoaded) return;

      const logicalWidth = canvasSize.width;
      const logicalHeight = canvasSize.height;
      canvas.width = Math.max(1, Math.floor(logicalWidth * previewDpr));
      canvas.height = Math.max(1, Math.floor(logicalHeight * previewDpr));
      ctx.setTransform(previewDpr, 0, 0, previewDpr, 0, 0);
      ctx.clearRect(0, 0, logicalWidth, logicalHeight);
      ctx.imageSmoothingEnabled = true;
      ctx.imageSmoothingQuality = "high";
      ctx.fillStyle = "#ffffff";
      ctx.fillRect(0, 0, logicalWidth, logicalHeight);

      const cx = logicalWidth / 2;
      const cy = logicalHeight / 2;

      ctx.save();
      ctx.translate(cx + pan.x, cy + pan.y);
      ctx.scale(zoom, zoom);
      ctx.translate(-cx, -cy);

      const shirtAspect = shirtImg.width / shirtImg.height;
      const maxW = logicalWidth * 0.92;
      const maxH = logicalHeight * 0.92;
      let drawW = maxW;
      let drawH = drawW / shirtAspect;

      if (drawH > maxH) {
        drawH = maxH;
        drawW = drawH * shirtAspect;
      }

      const shirtScale = getShirtScale(fit);
      drawW *= shirtScale;
      drawH *= shirtScale;

      const shirtX = (logicalWidth - drawW) / 2;
      const shirtY = (logicalHeight - drawH) / 2;

      ctx.drawImage(shirtImg, shirtX, shirtY, drawW, drawH);

      const currentBodyLengthCm = getBodyLengthCm(fit);
      const pxPerCm = drawH / currentBodyLengthCm;

      const designW = currentPlacement.widthCm * pxPerCm;
      const svgAspect = svgImg.width && svgImg.height ? svgImg.width / svgImg.height : 1;
      const designH = designW / svgAspect;

      const designCenterX = shirtX + (currentPlacement.x / 100) * drawW;
      const designCenterY = shirtY + (currentPlacement.y / 100) * drawH;
      const designX = designCenterX - designW / 2;
      const designY = designCenterY - designH / 2;

      renderInfoRef.current = {
        shirtX,
        shirtY,
        drawW,
        drawH,
        designX,
        designY,
        designW,
        designH,
        designCenterX,
        designCenterY,
        pxPerCm,
        currentBodyLengthCm,
        zoom,
        panX: pan.x,
        panY: pan.y,
      };

      ctx.save();
      ctx.translate(designCenterX, designCenterY);
      ctx.scale(currentPlacement.flipX ? -1 : 1, 1);
      ctx.drawImage(svgImg, -designW / 2, -designH / 2, designW, designH);
      ctx.restore();

      if (isDesignSelected && canEditCurrentSize) {
        drawSelectionBox(ctx, renderInfoRef.current);
      }

      ctx.restore();

      setStatus(`表示OK: ${selectedShirt?.code} / ${fit} / ${side} / ${selectedDesign?.name}`);
    };

    shirtImg.onload = () => {
      shirtLoaded = true;
      render();
    };
    svgImg.onload = () => {
      svgLoaded = true;
      render();
    };
    shirtImg.onerror = () => setStatus(`Tシャツ画像の読み込みに失敗: ${shirtSrc}`);
    svgImg.onerror = () => setStatus("SVG画像の表示に失敗。SVG内容を確認してください。");

    shirtImg.src = shirtSrc;
    svgImg.src = svgDataUrl;
  }, [
    shirtSrc,
    svgDataUrl,
    canvasSize,
    side,
    currentPlacement,
    selectedShirt,
    fit,
    selectedDesign,
    isDesignSelected,
    zoom,
    pan,
    canEditCurrentSize,
    isSwitchingDesign,
    previewDpr,
  ]);

  const updateCurrentPlacement = (patch) => {
    if (!canEditCurrentSize) return;
    setPlacement((prev) => ({
      ...prev,
      [side]: { ...prev[side], ...patch },
    }));
  };

  const refreshPlacementFromDesignsData = (message) => {
    const nextSessionMap = buildSavedMapFromDesignsData();
    sessionPlacementsRef.current = nextSessionMap;
    savePlacementsToStorage(nextSessionMap);
    const nextPlacement = buildPlacementState(nextSessionMap, designId, fit);
    setPlacement(nextPlacement);
    setIsDesignSelected(false);
    setStatus(message);
  };

  const removeStoredBaseSize = (sizeKey) => {
    if (!ensureDesignAdjustAuth()) return;

    const saved = loadSavedPlacements();

    if (saved?.[designId]?.[side]?.[sizeKey]) {
      delete saved[designId][side][sizeKey];
      if (Object.keys(saved[designId][side]).length === 0) delete saved[designId][side];
      savePlacementsToStorage(saved);
      refreshPlacementFromDesignsData(`${selectedDesign?.name} / ${side} の ${sizeKey} 保存値を削除しました`);
    } else {
      setStatus(`${selectedDesign?.name} / ${side} の ${sizeKey} 保存値はありません`);
    }
  };

  const removeAllStoredBaseSizesForSide = () => {
    if (!ensureDesignAdjustAuth()) return;

    const saved = loadSavedPlacements();
    let removedCount = 0;

    if (!saved?.[designId]?.[side]) {
      setStatus(`${selectedDesign?.name} / ${side} に削除できる保存値はありません`);
      return;
    }

    for (const sizeKey of EDITABLE_SIZES) {
      if (saved?.[designId]?.[side]?.[sizeKey]) {
        delete saved[designId][side][sizeKey];
        removedCount += 1;
      }
    }

    if (saved?.[designId]?.[side] && Object.keys(saved[designId][side]).length === 0) {
      delete saved[designId][side];
    }

    savePlacementsToStorage(saved);

    if (removedCount > 0) {
      refreshPlacementFromDesignsData(`${selectedDesign?.name} / ${side} の基準点を ${removedCount} 件削除しました`);
    } else {
      setStatus(`${selectedDesign?.name} / ${side} に削除できる基準点はありません`);
    }
  };

  const removeAllStorageAndReloadDesignsData = () => {
    if (!ensureDesignAdjustAuth()) return;

    clearAllPlacementsStorage();
    sessionPlacementsRef.current = {};
    refreshPlacementFromDesignsData("端末保存を全削除し、designs-data.js から再読込しました");
  };

  function buildPatchEntry(designKey, savedMap) {
    const defaults = getInitialPlacement(designKey);

    const frontSaved = {};
    const backSaved = {};

    const frontMWidth = roundPlacement(savedMap?.[designKey]?.front?.M ?? defaults?.front).widthCm;
    const backMWidth = roundPlacement(savedMap?.[designKey]?.back?.M ?? defaults?.back).widthCm;

    for (const sizeKey of EDITABLE_SIZES) {
      frontSaved[sizeKey] = {
        ...roundPlacement(savedMap?.[designKey]?.front?.[sizeKey] ?? defaults?.front),
        widthCm: frontMWidth,
      };
      backSaved[sizeKey] = {
        ...roundPlacement(savedMap?.[designKey]?.back?.[sizeKey] ?? defaults?.back),
        widthCm: backMWidth,
      };
    }

    return [
      `  "${designKey}": {`,
      "    placementDefaults: {",
      `      front: ${formatPlacementInline(frontSaved.M)},`,
      `      back: ${formatPlacementInline(backSaved.M)},`,
      "    },",
      "    savedBasePlacements: {",
      "      front: {",
      `        "120": ${formatPlacementInline(frontSaved["120"])},`,
      `        "M": ${formatPlacementInline(frontSaved.M)},`,
      `        "XXL": ${formatPlacementInline(frontSaved.XXL)},`,
      "      },",
      "      back: {",
      `        "120": ${formatPlacementInline(backSaved["120"])},`,
      `        "M": ${formatPlacementInline(backSaved.M)},`,
      `        "XXL": ${formatPlacementInline(backSaved.XXL)},`,
      "      },",
      "    },",
      "  },",
    ].join("\n");
  }

  function buildAllDesignsExportText() {
    const saved = loadSavedPlacements();
    const allIds = designs.map((d) => d.id);
    const entries = allIds.map((id) => buildPatchEntry(id, saved));

    return [
      "module.exports = {",
      entries
        .map((entry, index) => {
          const withComma = index < entries.length - 1 ? `${entry.slice(0, -1)},` : entry;
          return withComma;
        })
        .join("\n"),
      "};",
    ].join("\n");
  }

  const exportAllDesignsPatch = async () => {
    if (!ensureDesignAdjustAuth()) return;

    const text = buildAllDesignsExportText();
    setExportText(text);
    try {
      await navigator.clipboard.writeText(text);
      setStatus("全デザインの patch 完全版をコピーしました");
    } catch {
      setStatus("全デザインの patch 完全版を表示しました（手動コピーしてください）");
    }
  };

  const resetPlacement = () => {
    if (!canEditCurrentSize) return;
    if (!ensureDesignAdjustAuth()) return;

    const defaults = getInitialPlacement(designId);
    const next = { ...placement, [side]: safeClone(defaults[side]) };
    setPlacement(next);

    const saved = loadSavedPlacements();
    if (!saved[designId]) saved[designId] = {};
    if (!saved[designId].front) saved[designId].front = {};
    if (!saved[designId].back) saved[designId].back = {};

    saved[designId][side][fit] = safeClone(defaults[side]);
    if (!saved[designId][side].M) saved[designId][side].M = safeClone(defaults[side]);
    saved[designId][side].M.widthCm = defaults[side].widthCm;
    savePlacementsToStorage(saved);

    setIsDesignSelected(false);
  };

  const resetView = () => {
    setPan({ x: 0, y: 0 });
    setZoom(1);
    setIsDesignSelected(false);
  };

  const randomizeStyle = () => {
    const randomShirt = shirts[Math.floor(Math.random() * shirts.length)];
    const randomInk = inkPresets[Math.floor(Math.random() * inkPresets.length)];
    setShirtCode(randomShirt.code);
    setInkColor(randomInk.color);
  };

  const buildCanonicalFavoritePreview = async () => {
    if (!shirtSrc || !svgDataUrl || !currentPlacement) return "";

    const [shirtImg, svgImg] = await Promise.all([
      loadImageForPreview(shirtSrc),
      loadImageForPreview(svgDataUrl),
    ]);

    const work = document.createElement("canvas");
    work.width = canvasSize.width;
    work.height = canvasSize.height;
    const ctx = work.getContext("2d");
    if (!ctx) return "";

    ctx.clearRect(0, 0, work.width, work.height);
    ctx.fillStyle = "#ffffff";
    ctx.fillRect(0, 0, work.width, work.height);

    const shirtAspect = shirtImg.width / shirtImg.height;
    const maxW = work.width * 0.92;
    const maxH = work.height * 0.92;
    let drawW = maxW;
    let drawH = drawW / shirtAspect;

    if (drawH > maxH) {
      drawH = maxH;
      drawW = drawH * shirtAspect;
    }

    const shirtScale = getShirtScale(fit);
    drawW *= shirtScale;
    drawH *= shirtScale;

    const shirtX = (work.width - drawW) / 2;
    const shirtY = (work.height - drawH) / 2;

    ctx.drawImage(shirtImg, shirtX, shirtY, drawW, drawH);

    const currentBodyLengthCm = getBodyLengthCm(fit);
    const pxPerCm = drawH / currentBodyLengthCm;
    const designW = currentPlacement.widthCm * pxPerCm;
    const svgAspect = svgImg.width && svgImg.height ? svgImg.width / svgImg.height : 1;
    const designH = designW / svgAspect;
    const designCenterX = shirtX + (currentPlacement.x / 100) * drawW;
    const designCenterY = shirtY + (currentPlacement.y / 100) * drawH;

    ctx.save();
    ctx.translate(designCenterX, designCenterY);
    ctx.scale(currentPlacement.flipX ? -1 : 1, 1);
    ctx.drawImage(svgImg, -designW / 2, -designH / 2, designW, designH);
    ctx.restore();

    return buildFavoritePreviewDataUrl(work);
  };

  const exportHighResPng = async () => {
    if (!shirtSrc || !svgDataUrl || !currentPlacement) {
      setStatus("PNG保存に必要な表示がまだできていません");
      return;
    }

    try {
      const [shirtImg, svgImg] = await Promise.all([
        loadImageForPreview(shirtSrc),
        loadImageForPreview(svgDataUrl),
      ]);

      const exportCanvas = document.createElement("canvas");
      exportCanvas.width = HIGH_RES_EXPORT_SIZE;
      exportCanvas.height = HIGH_RES_EXPORT_SIZE;
      const ctx = exportCanvas.getContext("2d");
      if (!ctx) {
        setStatus("PNG保存用のcanvas作成に失敗しました");
        return;
      }

      ctx.clearRect(0, 0, exportCanvas.width, exportCanvas.height);
      ctx.fillStyle = "#ffffff";
      ctx.fillRect(0, 0, exportCanvas.width, exportCanvas.height);

      const cx = exportCanvas.width / 2;
      const cy = exportCanvas.height / 2;

      const panScaleX = exportCanvas.width / Math.max(1, canvasSize.width);
      const panScaleY = exportCanvas.height / Math.max(1, canvasSize.height);

      ctx.save();
      ctx.translate(cx + pan.x * panScaleX, cy + pan.y * panScaleY);
      ctx.scale(zoom, zoom);
      ctx.translate(-cx, -cy);

      const shirtAspect = shirtImg.width / shirtImg.height;
      const maxW = exportCanvas.width * 0.92;
      const maxH = exportCanvas.height * 0.92;
      let drawW = maxW;
      let drawH = drawW / shirtAspect;

      if (drawH > maxH) {
        drawH = maxH;
        drawW = drawH * shirtAspect;
      }

      const shirtScale = getShirtScale(fit);
      drawW *= shirtScale;
      drawH *= shirtScale;

      const shirtX = (exportCanvas.width - drawW) / 2;
      const shirtY = (exportCanvas.height - drawH) / 2;

      ctx.drawImage(shirtImg, shirtX, shirtY, drawW, drawH);

      const currentBodyLengthCm = getBodyLengthCm(fit);
      const pxPerCm = drawH / currentBodyLengthCm;
      const designW = currentPlacement.widthCm * pxPerCm;
      const svgAspect = svgImg.width && svgImg.height ? svgImg.width / svgImg.height : 1;
      const designH = designW / svgAspect;
      const designCenterX = shirtX + (currentPlacement.x / 100) * drawW;
      const designCenterY = shirtY + (currentPlacement.y / 100) * drawH;

      ctx.save();
      ctx.translate(designCenterX, designCenterY);
      ctx.scale(currentPlacement.flipX ? -1 : 1, 1);
      ctx.drawImage(svgImg, -designW / 2, -designH / 2, designW, designH);
      ctx.restore();

      ctx.restore();

      const exportResult = await downloadCanvas(
        exportCanvas,
        `anrocher-${shirtCode}-${fit}-${designId}-${side}-3000px.png`
      );

      if (exportResult === "shared") {
        setStatus(`高解像度PNGを共有メニューへ渡しました: ${HIGH_RES_EXPORT_SIZE}px`);
      } else if (exportResult === "cancelled") {
        setStatus("画像共有をキャンセルしました");
      } else {
        setStatus(`高解像度PNGを書き出しました: ${HIGH_RES_EXPORT_SIZE}px`);
      }
    } catch {
      setStatus("高解像度PNGの書き出しに失敗しました");
    }
  };

  const saveCurrentFavorite = async () => {
    if (!designId || !shirtSrc || !svgDataUrl || !currentPlacement) {
      setStatus("お気に入り保存に必要な表示がまだできていません");
      return;
    }

    let previewDataUrl = "";
    try {
      previewDataUrl = await buildCanonicalFavoritePreview();
    } catch {
      const canvas = canvasRef.current;
      previewDataUrl = buildFavoritePreviewDataUrl(canvas);
    }

    const favorite = {
      id: `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
      designId,
      designName: selectedDesign?.name || designId,
      shirtCode,
      shirtName: selectedShirt?.name || "",
      inkColor,
      fit,
      previewDataUrl,
      createdAt: new Date().toISOString(),
    };

    setFavorites((prev) => [favorite, ...prev].slice(0, MAX_FAVORITES));
    setStatus(`お気に入りを保存しました: ${favorite.designName} / ${fit} / ${shirtCode}`);
  };

  const applyFavorite = (favorite) => {
    if (!favorite) return;
    setDesignId(favorite.designId);
    setShirtCode(favorite.shirtCode);
    setInkColor(favorite.inkColor);
    setFit(favorite.fit);
    setStatus(`お気に入りを反映しました: ${favorite.designName || favorite.designId}`);
  };

  const removeFavorite = (favoriteId) => {
    setFavorites((prev) => prev.filter((item) => item.id !== favoriteId));
    setStatus("お気に入りを削除しました");
  };

  const zoomAtPoint = (deltaY) => {
    const intensity = 0.0015;
    setZoom((prev) => clamp(prev * Math.exp(-deltaY * intensity), MIN_ZOOM, MAX_ZOOM));
  };

  const zoomByButton = (direction) => {
    const factor = direction > 0 ? 1.1 : 1 / 1.1;
    setZoom((prev) => clamp(prev * factor, MIN_ZOOM, MAX_ZOOM));
  };

  const toLogicalPoint = (point, canvas) => ({
    x: (point.x - (canvas.width / 2 + pan.x)) / zoom + canvas.width / 2,
    y: (point.y - (canvas.height / 2 + pan.y)) / zoom + canvas.height / 2,
  });

  const startSinglePan = (e) => {
    panRef.current = {
      active: true,
      pointerId: e.pointerId,
      startX: e.clientX,
      startY: e.clientY,
      startOffsetX: pan.x,
      startOffsetY: pan.y,
    };
  };

  const clearInteractionState = () => {
    dragRef.current.active = false;
    dragRef.current.mode = null;
    dragRef.current.pointerId = null;
    panRef.current.active = false;
    panRef.current.pointerId = null;
    touchRef.current.active = false;
    touchRef.current.mode = null;
    touchRef.current.startDistance = 0;
    touchRef.current.startZoom = zoom;
  };

  const stopSingleTouchInteraction = () => {
    dragRef.current.active = false;
    dragRef.current.mode = null;
    dragRef.current.pointerId = null;
    panRef.current.active = false;
    panRef.current.pointerId = null;
  };

  const onPointerDown = (e) => {
    const canvas = canvasRef.current;
    if (!canvas || !currentPlacement) return;

    if (isMobile && e.pointerType === "touch") return;

    if (e.shiftKey && !isMobile) {
      startSinglePan(e);
      canvas.setPointerCapture?.(e.pointerId);
      return;
    }

    if (isTouchCapable && interactionMode === "pan") {
      clearInteractionState();
      setIsDesignSelected(false);
      startSinglePan(e);
      canvas.setPointerCapture?.(e.pointerId);
      return;
    }

    const info = renderInfoRef.current;
    if (!info) return;

    const point = getCanvasPoint(e.clientX, e.clientY, canvas);
    const logicalPoint = toLogicalPoint(point, canvas);

    if (canEditActive && hitResizeHandle(logicalPoint, info)) {
      dragRef.current = {
        active: true,
        mode: "resize-se",
        pointerId: e.pointerId,
        startCanvasX: logicalPoint.x,
        startCanvasY: logicalPoint.y,
        startPlacementX: currentPlacement.x,
        startPlacementY: currentPlacement.y,
        startWidthCm: currentPlacement.widthCm,
      };
      setIsDesignSelected(true);
      canvas.setPointerCapture?.(e.pointerId);
      return;
    }

    if (canEditActive && hitDesignBody(logicalPoint, info)) {
      dragRef.current = {
        active: true,
        mode: "move",
        pointerId: e.pointerId,
        startCanvasX: logicalPoint.x,
        startCanvasY: logicalPoint.y,
        startPlacementX: currentPlacement.x,
        startPlacementY: currentPlacement.y,
        startWidthCm: currentPlacement.widthCm,
      };
      setIsDesignSelected(true);
      canvas.setPointerCapture?.(e.pointerId);
      return;
    }

    setIsDesignSelected(false);
    setHoverMode(null);

    if (isTouchCapable && interactionMode === "design") {
      return;
    }
  };

  const onPointerMove = (e) => {
    const canvas = canvasRef.current;
    const info = renderInfoRef.current;
    if (!canvas || !info) return;

    if (panRef.current.active && panRef.current.pointerId === e.pointerId) {
      const dx = e.clientX - panRef.current.startX;
      const dy = e.clientY - panRef.current.startY;
      setPan({
        x: panRef.current.startOffsetX + dx,
        y: panRef.current.startOffsetY + dy,
      });
      return;
    }

    const point = getCanvasPoint(e.clientX, e.clientY, canvas);
    const logicalPoint = toLogicalPoint(point, canvas);

    if (!dragRef.current.active) {
      if (!canEditActive || (isTouchCapable && interactionMode !== "design")) {
        setHoverMode(null);
        return;
      }
      if (hitResizeHandle(logicalPoint, info)) {
        setHoverMode("resize-se");
      } else if (hitDesignBody(logicalPoint, info)) {
        setHoverMode("move");
      } else {
        setHoverMode(null);
      }
      return;
    }

    if (dragRef.current.pointerId !== e.pointerId) return;

    if (dragRef.current.mode === "move") {
      const dxCanvas = logicalPoint.x - dragRef.current.startCanvasX;
      const dyCanvas = logicalPoint.y - dragRef.current.startCanvasY;

      const deltaXPercent = (dxCanvas / info.drawW) * 100;
      const deltaYPercent = (dyCanvas / info.drawH) * 100;

      updateCurrentPlacement({
        x: clamp(dragRef.current.startPlacementX + deltaXPercent, 0, 100),
        y: clamp(dragRef.current.startPlacementY + deltaYPercent, 0, 100),
      });
      return;
    }

    if (dragRef.current.mode === "resize-se") {
      const dxCanvas = logicalPoint.x - dragRef.current.startCanvasX;
      const deltaCm = dxCanvas / info.pxPerCm;

      updateCurrentPlacement({
        widthCm: clamp(dragRef.current.startWidthCm + deltaCm, MIN_WIDTH_CM, MAX_WIDTH_CM),
      });
    }
  };

  const onTouchStart = (e) => {
    if (!isTouchCapable) return;

    const canvas = canvasRef.current;
    if (!canvas) return;

    if (e.touches.length === 2) {
      const [t1, t2] = e.touches;
      stopSingleTouchInteraction();
      setIsDesignSelected(false);
      touchRef.current.active = true;
      touchRef.current.mode = "pinch";
      touchRef.current.startDistance = getTouchDistance(t1, t2);
      touchRef.current.startZoom = zoom;
      e.preventDefault();
      return;
    }

    if (e.touches.length !== 1) return;
    if (touchRef.current.mode === "pinch") {
      e.preventDefault();
      return;
    }

    const info = renderInfoRef.current;
    if (!currentPlacement || !info) return;

    const touch = e.touches[0];
    const point = getCanvasPoint(touch.clientX, touch.clientY, canvas);
    const logicalPoint = toLogicalPoint(point, canvas);

    if (interactionMode === "pan") {
      panRef.current = {
        active: true,
        pointerId: "touch",
        startX: touch.clientX,
        startY: touch.clientY,
        startOffsetX: pan.x,
        startOffsetY: pan.y,
      };
      setIsDesignSelected(false);
      e.preventDefault();
      return;
    }

    if (canEditActive && hitResizeHandle(logicalPoint, info)) {
      dragRef.current = {
        active: true,
        mode: "resize-se",
        pointerId: "touch",
        startCanvasX: logicalPoint.x,
        startCanvasY: logicalPoint.y,
        startPlacementX: currentPlacement.x,
        startPlacementY: currentPlacement.y,
        startWidthCm: currentPlacement.widthCm,
      };
      setIsDesignSelected(true);
      e.preventDefault();
      return;
    }

    if (canEditActive && hitDesignBody(logicalPoint, info)) {
      dragRef.current = {
        active: true,
        mode: "move",
        pointerId: "touch",
        startCanvasX: logicalPoint.x,
        startCanvasY: logicalPoint.y,
        startPlacementX: currentPlacement.x,
        startPlacementY: currentPlacement.y,
        startWidthCm: currentPlacement.widthCm,
      };
      setIsDesignSelected(true);
      e.preventDefault();
      return;
    }

    setIsDesignSelected(false);
  };

  const onTouchMove = (e) => {
    if (!isTouchCapable) return;

    const canvas = canvasRef.current;
    if (!canvas) return;

    if (e.touches.length === 2) {
      const [t1, t2] = e.touches;
      const currentDistance = getTouchDistance(t1, t2);

      if (!touchRef.current.active || touchRef.current.mode !== "pinch" || touchRef.current.startDistance <= 0) {
        stopSingleTouchInteraction();
        setIsDesignSelected(false);
        touchRef.current.active = true;
        touchRef.current.mode = "pinch";
        touchRef.current.startDistance = currentDistance;
        touchRef.current.startZoom = zoom;
        e.preventDefault();
        return;
      }

      const scale = currentDistance / touchRef.current.startDistance;
      const nextZoom = clamp(touchRef.current.startZoom * scale, MIN_ZOOM, MAX_ZOOM);
      setZoom(nextZoom);
      e.preventDefault();
      return;
    }

    if (touchRef.current.mode === "pinch") {
      e.preventDefault();
      return;
    }

    const info = renderInfoRef.current;
    if (!info) return;
    if (e.touches.length !== 1) return;

    const touch = e.touches[0];

    if (panRef.current.active && panRef.current.pointerId === "touch") {
      const dx = touch.clientX - panRef.current.startX;
      const dy = touch.clientY - panRef.current.startY;
      setPan({
        x: panRef.current.startOffsetX + dx,
        y: panRef.current.startOffsetY + dy,
      });
      e.preventDefault();
      return;
    }

    if (!dragRef.current.active || dragRef.current.pointerId !== "touch") return;

    const point = getCanvasPoint(touch.clientX, touch.clientY, canvas);
    const logicalPoint = toLogicalPoint(point, canvas);

    if (dragRef.current.mode === "move") {
      const dxCanvas = logicalPoint.x - dragRef.current.startCanvasX;
      const dyCanvas = logicalPoint.y - dragRef.current.startCanvasY;

      const deltaXPercent = (dxCanvas / info.drawW) * 100;
      const deltaYPercent = (dyCanvas / info.drawH) * 100;

      updateCurrentPlacement({
        x: clamp(dragRef.current.startPlacementX + deltaXPercent, 0, 100),
        y: clamp(dragRef.current.startPlacementY + deltaYPercent, 0, 100),
      });
      e.preventDefault();
      return;
    }

    if (dragRef.current.mode === "resize-se") {
      const dxCanvas = logicalPoint.x - dragRef.current.startCanvasX;
      const deltaCm = dxCanvas / info.pxPerCm;

      updateCurrentPlacement({
        widthCm: clamp(dragRef.current.startWidthCm + deltaCm, MIN_WIDTH_CM, MAX_WIDTH_CM),
      });
      e.preventDefault();
    }
  };

  const onTouchEnd = (e) => {
    if (!isTouchCapable) return;

    if (touchRef.current.mode === "pinch") {
      if (e.touches.length < 2) {
        touchRef.current.active = false;
        touchRef.current.mode = null;
        touchRef.current.startDistance = 0;
        touchRef.current.startZoom = zoom;
        stopSingleTouchInteraction();
      }
      return;
    }

    if (e.touches.length === 1) {
      const touch = e.touches[0];

      if (interactionMode === "pan") {
        panRef.current = {
          active: true,
          pointerId: "touch",
          startX: touch.clientX,
          startY: touch.clientY,
          startOffsetX: pan.x,
          startOffsetY: pan.y,
        };
      } else {
        stopSingleTouchInteraction();
      }
      return;
    }

    clearInteractionState();
  };

  const endDrag = (e) => {
    if (dragRef.current.pointerId === e?.pointerId) {
      dragRef.current.active = false;
      dragRef.current.mode = null;
      dragRef.current.pointerId = null;
    }

    if (panRef.current.pointerId === e?.pointerId) {
      panRef.current.active = false;
      panRef.current.pointerId = null;
    }

    const canvas = canvasRef.current;
    if (canvas && e?.pointerId != null) {
      canvas.releasePointerCapture?.(e.pointerId);
    }
  };

  const toggleSection = (key) => {
    if (key === "designAdjust" && !openSections.designAdjust) {
      if (!ensureDesignAdjustAuth()) return;
    }

    setOpenSections((prev) => ({
      ...prev,
      [key]: !prev[key],
    }));
  };

  useEffect(() => {
    clearInteractionState();
  }, [interactionMode]);

  const canvasCursor = panRef.current.active
    ? "move"
    : isShiftPressed && !isMobile
    ? "grab"
    : isTouchCapable && interactionMode === "pan"
    ? "grab"
    : !canEditActive
    ? "default"
    : dragRef.current.active
    ? dragRef.current.mode === "resize-se"
      ? "nwse-resize"
      : "grabbing"
    : hoverMode === "resize-se"
    ? "nwse-resize"
    : hoverMode === "move"
    ? "grab"
    : "default";

  const currentBodyLengthCm = getBodyLengthCm(fit);
  const designWidthCm = currentPlacement?.widthCm ?? 0;
  const widthPercentOfBody = currentBodyLengthCm ? (designWidthCm / currentBodyLengthCm) * 100 : 0;

  const designsDataSavedBases = getSavedBasePlacements(designId) ?? {};
  const debugDesignsData120Front = roundPlacement(designsDataSavedBases?.front?.["120"] ?? getInitialPlacement(designId)?.front);
  const debugDesignsData120Back = roundPlacement(designsDataSavedBases?.back?.["120"] ?? getInitialPlacement(designId)?.back);

  const saved = loadSavedPlacements();
  const debugStorage120Front = saved?.[designId]?.front?.["120"] ? roundPlacement(saved?.[designId]?.front?.["120"]) : null;
  const debugStorage120Back = saved?.[designId]?.back?.["120"] ? roundPlacement(saved?.[designId]?.back?.["120"]) : null;
  const directSaved = Boolean(EDITABLE_SIZES.includes(fit) && saved?.[designId]?.[side]?.[fit]);
  const sideSavedMap = saved?.[designId]?.[side] || {};
  const sideDesignsDataMap = designsDataSavedBases?.[side] || {};

  const toggleSide = () => {
    setSide((prev) => (prev === "front" ? "back" : "front"));
  };

  return (
    <div
      style={{
        minHeight: "100vh",
        background: "#f5f5f4",
        padding: isMobile ? 10 : 16,
        boxSizing: "border-box",
        fontFamily: "sans-serif",
      }}
    >
      <div style={{ maxWidth: 1480, margin: "0 auto", display: "grid", gap: 16, minWidth: 0 }}>
        {appView === "order" ? (
          <OrderPanel
            compact={compact}
            isMobile={isMobile}
            isTablet={isTablet}
            draft={orderDraft}
            setDraft={setOrderDraft}
            savedOrders={savedOrders}
            setSavedOrders={setSavedOrders}
            onBackToMaker={() => setAppView("maker")}
            onAddCurrentSelection={addCurrentSelectionToOrder}
            onOpenBaseOrderPage={openBaseOrderPage}
            hasBaseOrderUrl={hasBaseOrderUrl}
            currentSelectionLabel={currentSelectionLabel}
            designs={designs}
            shirts={shirts}
          />
        ) : (
          <div
            style={{
              display: "grid",
              gap: isTablet ? 16 : 24,
              gridTemplateColumns: layoutColumns,
              alignItems: "start",
              minWidth: 0,
            }}
          >
            <div style={{ minWidth: 0 }}>
              <div style={panelStyle(compact)}>
                <div
                  style={{
                    display: "flex",
                    justifyContent: "space-between",
                    gap: 12,
                    alignItems: "center",
                    flexWrap: "wrap",
                    marginBottom: 16,
                    minWidth: 0,
                  }}
                >
                  <div style={{ minWidth: 0 }}>
                    <img
                      src="/title.svg"
                      alt="アンロシェカスタムTメーカー"
                      style={{
                        display: "block",
                        width: isMobile ? "100%" : 320,
                        maxWidth: "100%",
                        height: "auto",
                      }}
                    />
                    <div style={{ fontSize: 11, color: "#78716c", marginTop: 6 }}>{APP_VERSION} / data: {DESIGNS_DATA_VERSION}</div>
                  </div>

                  <div
                    style={{
                      display: "flex",
                      gap: 8,
                      flexWrap: "wrap",
                      width: isTablet ? "100%" : "auto",
                      minWidth: 0,
                    }}
                  >
                    <IconButton title="ランダム" ariaLabel="ランダム" compact={compact} onClick={randomizeStyle}>
                      <Dices size={compact ? 16 : 18} strokeWidth={2.25} />
                    </IconButton>
                    <IconButton title="お気に入り保存" ariaLabel="お気に入り保存" compact={compact} onClick={saveCurrentFavorite}>
                      <Star size={compact ? 16 : 18} strokeWidth={2.25} />
                    </IconButton>
                    <IconButton
                      title="高解像度PNG保存 / 共有（3000px）"
                      ariaLabel="高解像度PNG保存 / 共有（3000px）"
                      compact={compact}
                      onClick={exportHighResPng}
                    >
                      <Download size={compact ? 16 : 18} strokeWidth={2.25} />
                    </IconButton>
                  </div>
                </div>

                <div
                  style={{
                    display: "flex",
                    gap: 8,
                    alignItems: "center",
                    marginBottom: 10,
                    flexWrap: "wrap",
                    minWidth: 0,
                  }}
                >
                  <button
                    type="button"
                    title={side === "front" ? "裏を見る" : "表を見る"}
                    aria-label={side === "front" ? "裏を見る" : "表を見る"}
                    style={{
                      ...buttonStyle(false, compact),
                      display: "inline-flex",
                      alignItems: "center",
                      gap: 6,
                    }}
                    onClick={toggleSide}
                  >
                    <Repeat2 size={compact ? 15 : 17} strokeWidth={2.25} />
                    <span>{side === "front" ? "裏" : "表"}</span>
                  </button>

                  <IconButton title="縮小" ariaLabel="縮小" compact={compact} onClick={() => zoomByButton(-1)}>
                    <Minus size={compact ? 16 : 18} strokeWidth={2.25} />
                  </IconButton>
                  <div style={{ minWidth: 64, textAlign: "center", fontWeight: 700 }}>{Math.round(zoom * 100)}%</div>
                  <IconButton title="拡大" ariaLabel="拡大" compact={compact} onClick={() => zoomByButton(1)}>
                    <Plus size={compact ? 16 : 18} strokeWidth={2.25} />
                  </IconButton>
                  <IconButton title="表示リセット" ariaLabel="表示リセット" compact={compact} onClick={resetView}>
                    <House size={compact ? 16 : 18} strokeWidth={2.25} />
                  </IconButton>

                  <button
                    type="button"
                    title="発注書"
                    aria-label="発注書"
                    style={{
                      ...buttonStyle(false, compact),
                      display: "inline-flex",
                      alignItems: "center",
                      gap: 6,
                      marginLeft: compact ? 8 : 12,
                    }}
                    onClick={openOrderWithCurrentSelection}
                  >
                    <FileText size={compact ? 15 : 17} strokeWidth={2.25} />
                    <span>発注書</span>
                  </button>

                  <button
                    type="button"
                    title={hasBaseOrderUrl ? "BASEで注文する" : "このデザインはまだBASE未設定"}
                    aria-label={hasBaseOrderUrl ? "BASEで注文する" : "このデザインはまだBASE未設定"}
                    style={{
                      ...buttonStyle(false, compact),
                      display: "inline-flex",
                      alignItems: "center",
                      gap: 6,
                      opacity: hasBaseOrderUrl ? 1 : 0.5,
                      cursor: hasBaseOrderUrl ? "pointer" : "not-allowed",
                    }}
                    onClick={openBaseOrderPage}
                    disabled={!hasBaseOrderUrl}
                  >
                    <span>BASEで注文する</span>
                  </button>
                </div>

                <div
                  ref={wrapRef}
                  style={{
                    position: "relative",
                    background: "#fff",
                    borderRadius: compact ? 16 : 20,
                    padding: isMobile ? 8 : 12,
                    boxShadow: "inset 0 2px 8px rgba(0,0,0,0.05)",
                    overflow: "hidden",
                    maxHeight: isTablet ? "none" : "82vh",
                    minWidth: 0,
                    touchAction: "none",
                    overscrollBehavior: "none",
                    WebkitUserSelect: "none",
                    userSelect: "none",
                  }}
                >
                  <canvas
                    ref={canvasRef}
                    style={{
                      width: "100%",
                      maxWidth: "100%",
                      display: "block",
                      borderRadius: 16,
                      background: "#ffffff",
                      cursor: canvasCursor,
                      touchAction: "none",
                      opacity: isSwitchingDesign ? 0.96 : 1,
                    }}
                    onPointerDown={onPointerDown}
                    onPointerMove={onPointerMove}
                    onPointerUp={endDrag}
                    onPointerCancel={endDrag}
                    onPointerLeave={endDrag}
                    onTouchStart={onTouchStart}
                    onTouchMove={onTouchMove}
                    onTouchEnd={onTouchEnd}
                    onTouchCancel={onTouchEnd}
                    onWheel={(e) => {
                      if (!(e.ctrlKey || e.metaKey || e.altKey || e.shiftKey)) return;
                      e.preventDefault();
                      zoomAtPoint(e.deltaY);
                    }}
                  />
                </div>

                <div style={{ marginTop: 10, fontSize: 13, color: "#57534e" }}>
                  状態: {isSwitchingDesign ? "デザイン切替中..." : status}
                </div>

                <div
                  style={{
                    marginTop: 14,
                    border: "1px solid #e7e5e4",
                    borderRadius: 14,
                    background: "#fff",
                    padding: 12,
                  }}
                >
                  <div style={{ fontWeight: 800, fontSize: 15, marginBottom: 8 }}>お気に入り</div>
                  <div style={{ fontSize: 12, color: "#78716c", marginBottom: 10, lineHeight: 1.6 }}>
                    いまの Tカラー / インクカラー / サイズ / デザイン を小さい画像つきで保存します
                  </div>

                  {favorites.length === 0 ? (
                    <div
                      style={{
                        border: "1px dashed #d6d3d1",
                        borderRadius: 12,
                        padding: 14,
                        color: "#78716c",
                        background: "#fafaf9",
                        fontSize: 13,
                      }}
                    >
                      まだお気に入りはありません
                    </div>
                  ) : (
                    <div
                      style={{
                        display: "grid",
                        gridTemplateColumns: isMobile ? "repeat(3, minmax(0, 1fr))" : isTablet ? "repeat(4, minmax(0, 1fr))" : "repeat(5, minmax(0, 1fr))",
                        gap: 10,
                        minWidth: 0,
                      }}
                    >
                      {favorites.map((favorite) => (
                        <div
                          key={favorite.id}
                          style={{
                            border: "1px solid #e7e5e4",
                            borderRadius: 12,
                            overflow: "hidden",
                            background: "#fff",
                            boxShadow: "0 4px 12px rgba(0,0,0,0.04)",
                            minWidth: 0,
                          }}
                        >
                          <button
                            type="button"
                            onClick={() => applyFavorite(favorite)}
                            style={{
                              display: "block",
                              width: "100%",
                              border: "none",
                              background: "#fff",
                              padding: 0,
                              cursor: "pointer",
                              textAlign: "left",
                            }}
                          >
                            <div
                              style={{
                                width: "100%",
                                aspectRatio: "1 / 1",
                                background: "#ffffff",
                                overflow: "hidden",
                                borderBottom: "1px solid #f0ede9",
                              }}
                            >
                              {favorite.previewDataUrl ? (
                                <img
                                  src={favorite.previewDataUrl}
                                  alt={favorite.designName || favorite.designId}
                                  style={{ width: "100%", height: "100%", objectFit: "cover", display: "block" }}
                                />
                              ) : (() => {
                                const fallbackDesign = designs.find((item) => item.id === favorite.designId);
                                const fallbackThumb = fallbackDesign?.back || fallbackDesign?.front || "";
                                return fallbackThumb ? (
                                  <img
                                    src={fallbackThumb}
                                    alt={favorite.designName || favorite.designId}
                                    style={{ width: "100%", height: "100%", objectFit: "contain", display: "block", padding: 8, boxSizing: "border-box" }}
                                  />
                                ) : null;
                              })()}
                            </div>

                            <div style={{ padding: 8, display: "grid", gap: 4 }}>
                              <div style={{ fontWeight: 800, fontSize: 12, color: "#1c1917", lineHeight: 1.35, wordBreak: "break-word" }}>
                                {favorite.designName || favorite.designId}
                              </div>
                              <div style={{ fontSize: 11, color: "#57534e", lineHeight: 1.35 }}>
                                {favorite.shirtCode}
                                {(favorite.shirtName || shirts.find((item) => item.code === favorite.shirtCode)?.name)
                                  ? ` / ${favorite.shirtName || shirts.find((item) => item.code === favorite.shirtCode)?.name}`
                                  : ""}
                              </div>
                              <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
                                <span
                                  style={{
                                    width: 12,
                                    height: 12,
                                    borderRadius: 999,
                                    background: favorite.inkColor,
                                    border: "1px solid #d6d3d1",
                                    display: "inline-block",
                                    flexShrink: 0,
                                  }}
                                />
                                <span style={{ fontSize: 11, color: "#78716c" }}>{favorite.fit}</span>
                              </div>
                            </div>
                          </button>

                          <div style={{ padding: "0 8px 8px" }}>
                            <button
                              type="button"
                              onClick={() => removeFavorite(favorite.id)}
                              style={{
                                ...buttonStyle(false, true),
                                width: "100%",
                                fontSize: 12,
                                padding: "8px 10px",
                              }}
                            >
                              削除
                            </button>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>

                {exportText && (
                  <div
                    style={{
                      marginTop: 14,
                      border: "1px solid #d6d3d1",
                      borderRadius: 14,
                      background: "#fff",
                      padding: 12,
                      minWidth: 0,
                    }}
                  >
                    <div style={{ fontWeight: 800, fontSize: 15, marginBottom: 8 }}>patch 完全版</div>
                    <div style={{ fontSize: 12, color: "#78716c", marginBottom: 10, lineHeight: 1.6 }}>
                      design-placement-patches.cjs を丸ごと置き換える用
                    </div>

                    <textarea
                      value={exportText}
                      readOnly
                      style={{
                        width: "100%",
                        minHeight: isMobile ? 200 : 260,
                        resize: "vertical",
                        border: "1px solid #d6d3d1",
                        borderRadius: 10,
                        padding: 10,
                        boxSizing: "border-box",
                        fontFamily: "monospace",
                        fontSize: 12,
                        lineHeight: 1.5,
                        background: "#fafaf9",
                        minWidth: 0,
                      }}
                    />
                  </div>
                )}
              </div>
            </div>

            <div style={{ display: "grid", gap: isTablet ? 16 : 24, minWidth: 0 }}>
              <div style={panelStyle(compact)}>
                <SectionHeader
                  title="Tシャツ設定"
                  open={openSections.shirtSettings}
                  onToggle={() => toggleSection("shirtSettings")}
                  collapsible={isMobile}
                  isMobile={isMobile}
                  fontSize={isMobile ? 18 : 20}
                />

                {(!isMobile || openSections.shirtSettings) && (
                  <>
                    <label style={labelStyle()}>カラーコード</label>
                    <ShirtPicker shirts={shirts} shirtCode={shirtCode} setShirtCode={setShirtCode} side={side} compact={compact} />

                    <div style={{ height: 12 }} />

                    <label style={labelStyle()}>サイズ</label>
                    <div
                      style={{
                        display: "grid",
                        gridTemplateColumns: `repeat(${sizeColumns}, 1fr)`,
                        gap: 6,
                        marginBottom: 12,
                        minWidth: 0,
                      }}
                    >
                      {ALL_SIZES.map((size) => (
                        <SizeButton
                          key={size}
                          size={size}
                          active={fit === size}
                          editable={EDITABLE_SIZES.includes(size)}
                          onClick={() => setFit(size)}
                          compact={compact}
                        />
                      ))}
                    </div>

                    <div style={{ fontSize: 12, color: "#78716c", marginTop: -2, marginBottom: 14 }}>
                      ● が付いているサイズだけ編集できます
                    </div>
                  </>
                )}
              </div>

              <div style={panelStyle(compact)}>
                <SectionHeader
                  title="インクカラー（1色）"
                  open={openSections.inkColor}
                  onToggle={() => toggleSection("inkColor")}
                  collapsible={isMobile}
                  isMobile={isMobile}
                  fontSize={isMobile ? 18 : 20}
                />

                {(!isMobile || openSections.inkColor) && (
                  <>
                    <label style={labelStyle()}>プリセット</label>
                    <div style={{ display: "flex", gap: 8, flexWrap: "wrap", marginBottom: 14 }}>
                      {inkPresets.map((ink) => (
                        <button
                          key={ink.id}
                          title={ink.name}
                          onClick={() => setInkColor(ink.color)}
                          style={{
                            minWidth: compact ? 38 : 42,
                            height: compact ? 38 : 42,
                            padding: "0 10px",
                            borderRadius: 999,
                            background: ink.color,
                            border:
                              inkColor.toLowerCase() === ink.color.toLowerCase()
                                ? "3px solid #111"
                                : "1px solid #a8a29e",
                            cursor: "pointer",
                            boxShadow: "0 2px 6px rgba(0,0,0,0.1)",
                            color: ink.color === "#ffffff" ? "#111" : "transparent",
                          }}
                        >
                          ●
                        </button>
                      ))}
                    </div>

                    <div
                      style={{
                        display: "grid",
                        gridTemplateColumns: "56px 1fr",
                        gap: 10,
                        alignItems: "center",
                        minWidth: 0,
                      }}
                    >
                      <div
                        style={{
                          width: 50,
                          height: 42,
                          border: "1px solid #d6d3d1",
                          borderRadius: 8,
                          background: inkColor,
                        }}
                      />
                      <div
                        style={{
                          ...inputStyle(compact),
                          background: "#fafaf9",
                          color: "#44403c",
                          display: "flex",
                          alignItems: "center",
                          fontWeight: 700,
                        }}
                      >
                        {selectedInkName}
                      </div>
                    </div>
                  </>
                )}
              </div>

              <div style={panelStyle(compact)}>
                <SectionHeader
                  title="デザイン選択"
                  open={openSections.designPicker}
                  onToggle={() => toggleSection("designPicker")}
                  collapsible={isMobile}
                  isMobile={isMobile}
                  fontSize={isMobile ? 18 : 20}
                />

                {(!isMobile || openSections.designPicker) && (
                  <DesignPicker
                    designs={designs}
                    designId={designId}
                    setDesignId={setDesignId}
                    setIsSwitchingDesign={setIsSwitchingDesign}
                    columns={designColumns}
                    compact={compact}
                    isMobile={isMobile}
                  />
                )}
              </div>

              <div style={panelStyle(compact)}>
                <SectionHeader
                  title="デザイン調整"
                  open={openSections.designAdjust}
                  onToggle={() => toggleSection("designAdjust")}
                  collapsible={true}
                  isMobile={true}
                  fontSize={isMobile ? 18 : 20}
                  rightElement={
                    <span
                      style={{
                        display: "inline-flex",
                        alignItems: "center",
                        gap: 5,
                        fontSize: 11,
                        color: isDesignAdjustAuthed ? "#16a34a" : "#78716c",
                        border: "1px solid #e7e5e4",
                        borderRadius: 999,
                        padding: "4px 8px",
                        background: "#fafaf9",
                      }}
                    >
                      <Lock size={12} />
                      {isDesignAdjustAuthed ? "認証済み" : "ロック中"}
                    </span>
                  }
                />

                {openSections.designAdjust && (
                  <>
                    <div style={{ fontSize: 14, color: "#57534e", lineHeight: 1.7, marginBottom: 14 }}>
                      ・このセクションは簡易パスワード保護つき
                      <br />
                      ・リロード時は designs-data.js を優先（表示は session cache 優先）
                      <br />
                      ・編集できるのは 120 / M / XXL のみ
                      <br />
                      ・中間サイズは位置のみ補間、版幅は M 基準
                      <br />
                      ・スマホは下の「デザイン編集 ON/OFF」で1本指操作を切り替え
                    </div>

                    <div
                      style={{
                        display: "grid",
                        gridTemplateColumns: isMobile ? "1fr" : "1fr 1fr",
                        gap: 8,
                        marginBottom: 10,
                        minWidth: 0,
                      }}
                    >
                      <div style={{ ...inputStyle(compact), background: "#fafaf9", color: "#44403c", fontWeight: 700 }}>
                        X: {currentPlacement?.x?.toFixed?.(1) ?? 0}%
                      </div>
                      <div style={{ ...inputStyle(compact), background: "#fafaf9", color: "#44403c", fontWeight: 700 }}>
                        Y: {currentPlacement?.y?.toFixed?.(1) ?? 0}%
                      </div>
                      <div style={{ ...inputStyle(compact), background: "#fafaf9", color: "#44403c", fontWeight: 700 }}>
                        版幅: {designWidthCm.toFixed(1)}cm
                      </div>
                      <div style={{ ...inputStyle(compact), background: "#fafaf9", color: "#44403c", fontWeight: 700 }}>
                        身丈: {currentBodyLengthCm}cm
                      </div>
                      <div style={{ ...inputStyle(compact), background: "#fafaf9", color: "#44403c", fontWeight: 700 }}>
                        身丈比: {widthPercentOfBody.toFixed(1)}%
                      </div>
                      <div style={{ ...inputStyle(compact), background: "#fafaf9", color: "#44403c", fontWeight: 700 }}>
                        種別: {directSaved ? "基準点" : "designs-data / 補間"}
                      </div>
                      <div
                        style={{
                          ...inputStyle(compact),
                          background: "#fafaf9",
                          color: "#44403c",
                          fontWeight: 700,
                          gridColumn: isMobile ? "auto" : "1 / -1",
                        }}
                      >
                        編集: {canEditCurrentSize ? "可 / 版幅は常にM基準" : "不可（補間のみ）"}
                      </div>
                    </div>

                    <div style={{ marginBottom: 14, display: "grid", gap: 8 }}>
                      <button
                        style={{
                          ...buttonStyle(isEditMode, compact),
                          width: "100%",
                          opacity: canEditCurrentSize ? 1 : 0.5,
                          cursor: canEditCurrentSize ? "pointer" : "not-allowed",
                        }}
                        disabled={!canEditCurrentSize}
                        onClick={() => {
                          if (!canEditCurrentSize) return;
                          if (!ensureDesignAdjustAuth()) return;
                          setIsEditMode((prev) => !prev);
                          setIsDesignSelected(false);
                        }}
                      >
                        デザイン編集 {isEditMode ? "ON" : "OFF"}
                      </button>

                      <button
                        style={{
                          ...buttonStyle(false, compact),
                          width: "100%",
                          opacity: canEditCurrentSize ? 1 : 0.5,
                          cursor: canEditCurrentSize ? "pointer" : "not-allowed",
                        }}
                        disabled={!canEditCurrentSize}
                        onClick={resetPlacement}
                      >
                        この面の位置をリセット
                      </button>

                      <button
                        style={{
                          ...buttonStyle(false, compact),
                          width: "100%",
                        }}
                        onClick={exportAllDesignsPatch}
                      >
                        全デザインを書き出し
                      </button>
                    </div>

                    <div
                      style={{
                        borderTop: "1px solid #e7e5e4",
                        paddingTop: 14,
                        display: "grid",
                        gap: 8,
                      }}
                    >
                      <div style={{ fontWeight: 800, fontSize: 15, color: "#44403c" }}>デバッグ / 保存クリア</div>

                      <div style={{ fontSize: 12, color: "#78716c", lineHeight: 1.6 }}>
                        storage key: {PLACEMENT_STORAGE_KEY}
                        <br />
                        touch device: {isTouchCapable ? "yes" : "no"}
                        <br />
                        auth session: {isDesignAdjustAuthed ? "ok" : "locked"}
                        <br />
                        designs-data： 120 {sideDesignsDataMap["120"] ? "あり" : "なし"} / M {sideDesignsDataMap.M ? "あり" : "なし"} / XXL {sideDesignsDataMap.XXL ? "あり" : "なし"}
                        <br />
                        端末保存： 120 {sideSavedMap["120"] ? "あり" : "なし"} / M {sideSavedMap.M ? "あり" : "なし"} / XXL {sideSavedMap.XXL ? "あり" : "なし"}
                      </div>

                      <div
                        style={{
                          border: "1px solid #e7e5e4",
                          borderRadius: 12,
                          background: "#fafaf9",
                          padding: 10,
                          fontSize: 11,
                          color: "#57534e",
                          lineHeight: 1.65,
                          wordBreak: "break-word",
                        }}
                      >
                        <div style={{ fontWeight: 800, marginBottom: 6 }}>120デバッグ</div>
                        <div>designs-data front: x {debugDesignsData120Front.x} / y {debugDesignsData120Front.y} / w {debugDesignsData120Front.widthCm}</div>
                        <div>designs-data back: x {debugDesignsData120Back.x} / y {debugDesignsData120Back.y} / w {debugDesignsData120Back.widthCm}</div>
                        <div>storage front: {debugStorage120Front ? `x ${debugStorage120Front.x} / y ${debugStorage120Front.y} / w ${debugStorage120Front.widthCm}` : "none"}</div>
                        <div>storage back: {debugStorage120Back ? `x ${debugStorage120Back.x} / y ${debugStorage120Back.y} / w ${debugStorage120Back.widthCm}` : "none"}</div>
                        <div>current side value: x {roundPlacement(currentPlacement).x} / y {roundPlacement(currentPlacement).y} / w {roundPlacement(currentPlacement).widthCm}</div>
                      </div>

                      <div
                        style={{
                          display: "grid",
                          gridTemplateColumns: isMobile ? "1fr" : "repeat(3, 1fr)",
                          gap: 8,
                        }}
                      >
                        <button style={buttonStyle(false, compact)} onClick={() => removeStoredBaseSize("120")}>
                          120削除
                        </button>
                        <button style={buttonStyle(false, compact)} onClick={() => removeStoredBaseSize("M")}>
                          M削除
                        </button>
                        <button style={buttonStyle(false, compact)} onClick={() => removeStoredBaseSize("XXL")}>
                          XXL削除
                        </button>
                      </div>

                      <button
                        style={{
                          ...buttonStyle(false, compact),
                          width: "100%",
                          border: "1px solid #fca5a5",
                          background: "#fff5f5",
                        }}
                        onClick={removeAllStoredBaseSizesForSide}
                      >
                        この面の基準点を全部削除
                      </button>

                      <button
                        style={{
                          ...buttonStyle(false, compact),
                          width: "100%",
                          border: "1px solid #f59e0b",
                          background: "#fffaf0",
                        }}
                        onClick={removeAllStorageAndReloadDesignsData}
                      >
                        端末保存を全削除して designs-data.js に戻す
                      </button>
                    </div>
                  </>
                )}
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
